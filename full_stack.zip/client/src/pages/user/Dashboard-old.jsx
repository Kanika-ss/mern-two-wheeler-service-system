// import React, { useState, useEffect, useContext } from 'react';
// import { AuthContext } from '../../context/AuthContext';
// import api from '../../services/api';

// const UserDashboard = () => {
//   const { user } = useContext(AuthContext);
//   const [form, setForm] = useState({
//     bikeModel: '',
//     bikeBrand: '',
//     registrationNumber: '',
//     serviceType: 'General Service',
//     preferredDate: '',
//     preferredTime: '',
//   });
//   const [msg, setMsg] = useState('');
//   const [bookings, setBookings] = useState([]);

//   const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const res = await api.post('/api/bookings', form);
//       setMsg(res.data.msg);
//       fetchBookings(); // refresh list
//     } catch (err) {
//       setMsg(err.response?.data?.msg || 'Error creating booking');
//     }
//   };

//   const fetchBookings = async () => {
//     try {
//       const res = await api.get('/api/bookings');
//       setBookings(res.data);
//     } catch (err) {
//       console.error(err);
//     }
//   };

//   useEffect(() => {
//     fetchBookings();
//   }, []);

//   return (
//     <div style={{ padding: 20 }}>
//       <h2>Welcome, {user.name}</h2>
//       <h3>Book a Service</h3>
//       <form onSubmit={handleSubmit}>
//         <input name="bikeModel" placeholder="Bike Model" onChange={handleChange} /><br />
//         <input name="bikeBrand" placeholder="Bike Brand" onChange={handleChange} /><br />
//         <input name="registrationNumber" placeholder="Registration Number" onChange={handleChange} /><br />
//         <select name="serviceType" onChange={handleChange} value={form.serviceType}>
//           <option>General Service</option>
//           <option>Oil Change</option>
//           <option>Repair</option>
//         </select><br />
//         <input name="preferredDate" type="date" onChange={handleChange} /><br />
//         <input name="preferredTime" type="time" onChange={handleChange} /><br />
//         <button type="submit">Book Service</button>
//       </form>
//       <p>{msg}</p>

//       <h3>Your Bookings</h3>
//       <table border="1" cellPadding="5">
//         <thead>
//           <tr>
//             <th>Bike</th>
//             <th>Reg. No.</th>
//             <th>Service Type</th>
//             <th>Date</th>
//             <th>Time</th>
//             <th>Status</th>
//           </tr>
//         </thead>
//         <tbody>
//           {bookings.map((b) => (
//             <tr key={b._id}>
//               <td>{b.bikeBrand} {b.bikeModel}</td>
//               <td>{b.registrationNumber}</td>
//               <td>{b.serviceType}</td>
//               <td>{new Date(b.preferredDate).toLocaleDateString()}</td>
//               <td>{b.preferredTime}</td>
//               <td>{b.status}</td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// };

// export default UserDashboard;




// import React, { useState, useEffect, useContext } from 'react';
// import { AuthContext } from '../../context/AuthContext';
// import api from '../../services/api';
// import { useNavigate } from 'react-router-dom';

// const UserDashboard = () => {
//   const { user } = useContext(AuthContext);
//   const [form, setForm] = useState({
//     bikeModel: '',
//     bikeBrand: '',
//     registrationNumber: '',
//     serviceType: 'General Service',
//     preferredDate: '',
//     preferredTime: '',
//   });
//   const [msg, setMsg] = useState('');
//   const [bookings, setBookings] = useState([]);
//   const navigate = useNavigate();

//   const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const res = await api.post('/api/bookings', form);
//       setMsg(res.data.msg);
//       setForm({
//         bikeModel: '',
//         bikeBrand: '',
//         registrationNumber: '',
//         serviceType: 'General Service',
//         preferredDate: '',
//         preferredTime: '',
//       }); // reset form
//       fetchBookings();
//     } catch (err) {
//       setMsg(err.response?.data?.msg || 'Error creating booking');
//     }
//   };

//   const fetchBookings = async () => {
//     try {
//       const res = await api.get('/api/bookings');
//       setBookings(res.data);
//     } catch (err) {
//       console.error(err);
//     }
//   };

//   useEffect(() => {
//     fetchBookings();
//   }, []);

//   const handleLogout = () => {
//     // clear user session or token
//     localStorage.removeItem('token');
//     navigate('/login');
//   };

//   return (
//     <div style={styles.pageContainer}>
//       {/* Header */}
//       <header style={styles.header}>
//         <div style={styles.logoSection}>
//           <img src="/images/logo.png" alt="Logo" style={styles.logo} />
//           <h2 style={{ margin: 0 }}>Two Wheeler Service</h2>
//         </div>
//         <nav style={styles.nav}>
//           <span style={styles.navItem}>Profile</span>
//           <span style={styles.navItem} onClick={handleLogout}>Logout</span>
//         </nav>
//       </header>

//       {/* Main Content */}
//       <div style={styles.content}>
//         <h2>Welcome, {user?.name}</h2>
//         <p style={styles.description}>
//           Book your two-wheeler service easily and keep track of your service history.
//         </p>

//         {/* Booking Form */}
//         <div style={styles.formCard}>
//           <h3>Book a Service</h3>
//           <form onSubmit={handleSubmit} style={styles.form}>
//             <label style={styles.label}>Bike Model</label>
//             <input name="bikeModel" placeholder="Bike Model" value={form.bikeModel} onChange={handleChange} style={styles.input} />
//             <label style={styles.label}>Bike Brand</label>
//             <input name="bikeBrand" placeholder="Bike Brand" value={form.bikeBrand} onChange={handleChange} style={styles.input} />
//             <label style={styles.label}>Registration Number</label>
//             <input name="registrationNumber" placeholder="Registration Number" value={form.registrationNumber} onChange={handleChange} style={styles.input} />
//             <label style={styles.label}>Service Type</label>
//             <select name="serviceType" value={form.serviceType} onChange={handleChange} style={styles.input}>
//               <option>General Service</option>
//               <option>Oil Change</option>
//               <option>Repair</option>
//             </select>
//             <div style={styles.dateTimeRow}>
//   <div style={styles.fieldGroup}>
//     <label htmlFor="preferredDate" style={styles.label}>Preferred Date</label>
//     <input
//       id="preferredDate"
//       name="preferredDate"
//       type="date"
//       value={form.preferredDate}
//       onChange={handleChange}
//       style={styles.inputInline}
//     />
//   </div>
//   <div style={styles.fieldGroup}>
//     <label htmlFor="preferredTime" style={styles.label}>Preferred Time</label>
//     <input
//       id="preferredTime"
//       name="preferredTime"
//       type="time"
//       value={form.preferredTime}
//       onChange={handleChange}
//       style={styles.inputInline}
//     />
//   </div>
// </div>

//             <br></br><button type="submit" style={styles.submitButton}>Book Service</button>
//           </form>
//           {msg && <p style={msg.includes("Error") ? styles.errorMsg : styles.successMsg}>{msg}</p>}
//         </div>

//         {/* Bookings Table */}
//         <div style={styles.tableCard}>
//           <h3>Your Bookings</h3>
//           <table style={styles.table}>
//             <thead>
//               <tr>
//                 <th style={styles.th}>Bike</th>
//                 <th style={styles.th}>Reg. No.</th>
//                 <th style={styles.th}>Service Type</th>
//                 <th style={styles.th}>Date</th>
//                 <th style={styles.th}>Time</th>
//                 <th style={styles.th}>Status</th>
//               </tr>
//             </thead>
//             <tbody>
//               {bookings.map((b) => (
//                 <tr key={b._id} style={styles.trHover}>
//                   <td style={styles.td}>{b.bikeBrand} {b.bikeModel}</td>
//                   <td style={styles.td}>{b.registrationNumber}</td>
//                   <td style={styles.td}>{b.serviceType}</td>
//                   <td style={styles.td}>{new Date(b.preferredDate).toLocaleDateString()}</td>
//                   <td style={styles.td}>{b.preferredTime}</td>
//                   <td style={styles.td}>{b.status}</td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>

//         </div>
//       </div>
//     </div>
//   );
// };

// const styles = {
//   pageContainer: {
//     fontFamily: 'Arial, sans-serif',
//     background: '#f5f5f5',
//     minHeight: '100vh',
//   },
//   header: {
//     display: 'flex',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     padding: 20,
//     background: '#333',
//     color: '#fff',
//   },
//   logoSection: {
//     display: 'flex',
//     alignItems: 'center',
//   },
//   logo: {
//     width: 50,
//     height: 50,
//     marginRight: 10,
//   },
//   nav: {
//     display: 'flex',
//     gap: 20,
//   },
//   navItem: {
//     cursor: 'pointer',
//     textDecoration: 'underline',
//   },
//   content: {
//     padding: '30px 60px',
//   },
//   description: {
//     fontSize: 16,
//     marginBottom: 20,
//   },
//   formCard: {
//     background: '#fff',
//     padding: 20,
//     borderRadius: 8,
//     marginBottom: 30,
//     boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
//   },
//   input: {
//     display: 'block',
//     width: '98%',
//     padding: 10,
//     marginBottom: 10,
//     borderRadius: 4,
//     border: '1px solid #ccc',
//   },
//   label: {
//   display: 'block',
//   fontWeight: 'bold',
//   marginBottom: 5,
//   marginTop: 10,
//   color: '#333',
//   fontSize: 14,
// },
// dateTimeRow: {
//   display: 'flex',
//   justifyContent: 'space-between',
//   gap: '20px',
//   alignItems: 'center',
// },

// fieldGroup: {
//   flex: 1,
// },

// inputInline: {
//   display: 'block',
//   width: '98%',
//   padding: 10,
//   marginTop: 5,
//   borderRadius: 4,
//   border: '1px solid #ccc',
// },

//   submitButton: {
//     padding: '10px 20px',
//     background: '#333',
//     color: '#fff',
//     border: 'none',
//     borderRadius: 4,
//     cursor: 'pointer',
//   },
//   successMsg: { color: 'green', marginTop: 10 },
//   errorMsg: { color: 'red', marginTop: 10 },

//   /* --- Table Styles --- */
//   tableCard: {
//     background: '#fff',
//     padding: 20,
//     borderRadius: 8,
//     boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
//     overflowX: 'auto',
//   },
//   table: {
//     width: '100%',
//     borderCollapse: 'collapse',
//     textAlign: 'center',
//   },
//   th: {
//     background: '#333',
//     color: '#fff',
//     padding: '12px 8px',
//     borderBottom: '2px solid #444',
//   },
//   td: {
//     padding: '10px 8px',
//     borderBottom: '1px solid #ddd',
//   },
//   trHover: {
//     backgroundColor: '#f9f9f9',
//   },
// };


// export default UserDashboard;


import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../../context/AuthContext';
import api from '../../services/api';
import { useNavigate } from 'react-router-dom';

const UserDashboard = () => {
  const { user } = useContext(AuthContext);
  const [form, setForm] = useState({
    bikeModel: '',
    bikeBrand: '',
    registrationNumber: '',
    serviceType: 'General Service',
    preferredDate: '',
    preferredTime: '',
    pickupAddress: '',
    pickupDate: '',
    pickupTime: '',
  });
  const [msg, setMsg] = useState('');
  const [bookings, setBookings] = useState([]);
  const [showProfile, setShowProfile] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const navigate = useNavigate();

  // AUTH CHECK
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) navigate('/login');
  }, [navigate]);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const fetchBookings = async () => {
    try {
      const res = await api.get('/api/bookings');
      setBookings(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    // basic validation
    if (!form.bikeModel || !form.bikeBrand || !form.registrationNumber || !form.pickupAddress) {
      setMsg('Please fill all required fields');
      return;
    }

    try {
      if (editingId) {
        const res = await api.put(`/api/bookings/${editingId}`, form);
        setMsg(res.data.msg);
        setEditingId(null);
      } else {
        const res = await api.post('/api/bookings', form);
        setMsg(res.data.msg);
      }

      setForm({
        bikeModel: '',
        bikeBrand: '',
        registrationNumber: '',
        serviceType: 'General Service',
        preferredDate: '',
        preferredTime: '',
        pickupAddress: '',
        pickupDate: '',
        pickupTime: '',
      });
      fetchBookings();
    } catch (err) {
      setMsg(err.response?.data?.msg || 'Error saving booking');
    }
  };

  const handleEdit = (booking) => {
    setEditingId(booking._id);
    setForm({
      bikeModel: booking.bikeModel,
      bikeBrand: booking.bikeBrand,
      registrationNumber: booking.registrationNumber,
      serviceType: booking.serviceType,
      preferredDate: booking.preferredDate?.split('T')[0] || '',
      preferredTime: booking.preferredTime,
      pickupAddress: booking.pickupAddress || '',
      pickupDate: booking.pickupDate?.split('T')[0] || '',
      pickupTime: booking.pickupTime || '',
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this booking?')) return;
    try {
      const res = await api.delete(`/api/bookings/${id}`);
      setMsg(res.data.msg);
      fetchBookings();
    } catch (err) {
      setMsg(err.response?.data?.msg || 'Error deleting booking');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <div style={styles.pageContainer}>
      {/* Header */}
      <header style={styles.header}>
        <div style={styles.logoSection}>
          <img src="/images/logo.png" alt="Logo" style={styles.logo} />
          <h2 style={{ margin: 0 }}>Two Wheeler Service</h2>
        </div>
        <nav style={styles.nav}>
          {/* <span style={styles.navItem} onClick={() => navigate('/profile')}>Profile</span> */}
          <span style={styles.navItem} onClick={() => setShowProfile(true)}>Profile</span>
          <span style={styles.navItem} onClick={handleLogout}>Logout</span>
        </nav>
      </header>

      {/* Main Content */}
      <div style={styles.content}>
        <h2>Welcome, {user?.name}</h2>
        <p style={styles.description}>
          Book your two-wheeler service easily and keep track of your service history.
        </p>

        {/* Booking Form */}
        <div style={styles.formCard}>
          <h3>{editingId ? 'Edit Booking' : 'Book a Service'}</h3>
          <form onSubmit={handleSubmit} style={styles.form}>
            <label style={styles.label}>Bike Model</label>
            <input name="bikeModel" value={form.bikeModel} onChange={handleChange} placeholder="Bike Model" style={styles.input} />
            <label style={styles.label}>Bike Brand</label>
            <input name="bikeBrand" value={form.bikeBrand} onChange={handleChange} placeholder="Bike Brand" style={styles.input} />
            <label style={styles.label}>Registration Number</label>
            <input name="registrationNumber" value={form.registrationNumber} onChange={handleChange} placeholder="Registration Number" style={styles.input} />
            <label style={styles.label}>Pickup Address</label>
            <input name="pickupAddress" value={form.pickupAddress} onChange={handleChange} placeholder="Enter pickup address" style={styles.input} />

            <div style={styles.dateTimeRow}>
              <div style={styles.fieldGroup}>
                <label style={styles.label}>Pickup Date</label>
                <input type="date" name="pickupDate" value={form.pickupDate} onChange={handleChange} style={styles.inputInline} />
              </div>
              <div style={styles.fieldGroup}>
                <label style={styles.label}>Pickup Time</label>
                <input type="time" name="pickupTime" value={form.pickupTime} onChange={handleChange} style={styles.inputInline} />
              </div>
            </div>

            <label style={styles.label}>Service Type</label>
            <select name="serviceType" value={form.serviceType} onChange={handleChange} style={styles.input}>
              <option>General Service</option>
              <option>Oil Change</option>
              <option>Repair</option>
            </select>

            <div style={styles.dateTimeRow}>
              <div style={styles.fieldGroup}>
                <label style={styles.label}>Preferred Delivery Date</label>
                <input type="date" name="preferredDate" value={form.preferredDate} onChange={handleChange} style={styles.inputInline} />
              </div>
              <div style={styles.fieldGroup}>
                <label style={styles.label}>Preferred Delivery Time</label>
                <input type="time" name="preferredTime" value={form.preferredTime} onChange={handleChange} style={styles.inputInline} />
              </div>
            </div>

            <br />
            <button type="submit" style={styles.submitButton}>
              {editingId ? 'Update Booking' : 'Book Service'}
            </button>
          </form>
          {msg && <p style={msg.includes('Error') ? styles.errorMsg : styles.successMsg}>{msg}</p>}
        </div>

        {/* Bookings Table */}
        <div style={styles.tableCard}>
          <h3>Your Bookings</h3>
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>Bike</th>
                <th style={styles.th}>Reg. No.</th>
                <th style={styles.th}>Service Type</th>
                <th style={styles.th}>Pickup</th>
                <th style={styles.th}>Date</th>
                <th style={styles.th}>Time</th>
                <th style={styles.th}>Status</th>
                <th style={styles.th}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((b) => (
                <tr key={b._id} style={styles.trHover}>
                  <td style={styles.td}>{b.bikeBrand} {b.bikeModel}</td>
                  <td style={styles.td}>{b.registrationNumber}</td>
                  <td style={styles.td}>{b.serviceType}</td>
                  <td style={styles.td}>{b.pickupAddress}</td>
                  <td style={styles.td}>{new Date(b.pickupDate).toLocaleDateString()}</td>
                  <td style={styles.td}>{b.pickupTime}</td>
                  <td style={styles.td}>{b.status}</td>
                  <td style={styles.td}>
                    {b.status === 'Pending' ? (
                      <>
                        <button onClick={() => handleEdit(b)} style={styles.editBtn}>Edit</button>
                        <button onClick={() => handleDelete(b._id)} style={styles.deleteBtn}>Delete</button>
                      </>
                    ) : (
                      <span style={{ color: '#888' }}>Locked</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {/* Profile Popup Modal */}
{showProfile && (
  <div style={styles.modalOverlay}>
    <div style={styles.modalContainer}>
      <h2 style={styles.modalTitle}>Profile Details</h2>
      <div style={styles.profileDetails}>
        <p><strong>Name:</strong> {user?.name}</p>
        <p><strong>Email:</strong> {user?.email}</p>
        <p><strong>Phone:</strong> {user?.phone}</p>
      </div>
      <button style={styles.closeButton} onClick={() => setShowProfile(false)}>Close</button>
    </div>
  </div>
)}

    </div>
  );
};

//  Styles (same base, added buttons)
const styles = {
  pageContainer: { fontFamily: 'Arial, sans-serif', background: '#f5f5f5', minHeight: '100vh' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: 20, background: '#333', color: '#fff' },
  logoSection: { display: 'flex', alignItems: 'center' },
  logo: { width: 50, height: 50, marginRight: 10 },
  nav: { display: 'flex', gap: 20 },
  navItem: { cursor: 'pointer', textDecoration: 'underline' },
  content: { padding: '30px 60px' },
  description: { fontSize: 16, marginBottom: 20 },
  formCard: { background: '#fff', padding: 20, borderRadius: 8, marginBottom: 30, boxShadow: '0 2px 8px rgba(0,0,0,0.1)' },
  input: { display: 'block', width: '98%', padding: 10, marginBottom: 10, borderRadius: 4, border: '1px solid #ccc' },
  label: { display: 'block', fontWeight: 'bold', marginBottom: 5, marginTop: 10, color: '#333', fontSize: 14 },
  dateTimeRow: { display: 'flex', justifyContent: 'space-between', gap: '20px', alignItems: 'center' },
  fieldGroup: { flex: 1 },
  inputInline: { display: 'block', width: '98%', padding: 10, marginTop: 5, borderRadius: 4, border: '1px solid #ccc' },
  submitButton: { padding: '10px 20px', background: '#333', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer' },
  editBtn: { background: '#007bff', color: '#fff', border: 'none', padding: '5px 10px', borderRadius: 4, marginRight: 5, cursor: 'pointer' },
  deleteBtn: { background: '#dc3545', color: '#fff', border: 'none', padding: '5px 10px', borderRadius: 4, cursor: 'pointer' },
  successMsg: { color: 'green', marginTop: 10 },
  errorMsg: { color: 'red', marginTop: 10 },
  tableCard: { background: '#fff', padding: 20, borderRadius: 8, boxShadow: '0 2px 8px rgba(0,0,0,0.1)', overflowX: 'auto' },
  table: { width: '100%', borderCollapse: 'collapse', textAlign: 'center' },
  th: { background: '#333', color: '#fff', padding: '12px 8px', borderBottom: '2px solid #444' },
  td: { padding: '10px 8px', borderBottom: '1px solid #ddd' },
  trHover: { backgroundColor: '#f9f9f9' },
  modalOverlay: {
  position: 'fixed',
  top: 0,
  left: 0,
  width: '100%',
  height: '100%',
  backgroundColor: 'rgba(0,0,0,0.6)',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  zIndex: 1000,
},

modalContainer: {
  backgroundColor: '#fff',
  padding: '30px',
  borderRadius: '12px',
  width: '90%',
  maxWidth: '500px',
  boxShadow: '0 4px 15px rgba(0,0,0,0.3)',
  textAlign: 'center',
  animation: 'fadeIn 0.3s ease-in-out',
},

modalTitle: {
  fontSize: '22px',
  marginBottom: '15px',
  color: '#333',
},

profileDetails: {
  textAlign: 'left',
  lineHeight: '1.8',
  fontSize: '16px',
  marginBottom: '20px',
},

closeButton: {
  background: '#333',
  color: '#fff',
  border: 'none',
  padding: '10px 20px',
  borderRadius: '8px',
  cursor: 'pointer',
  fontWeight: 'bold',
},

};



export default UserDashboard;
