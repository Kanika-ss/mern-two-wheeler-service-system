import { useNavigate } from "react-router-dom";
import React, { useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";

const Login = () => {
  const [form, setForm] = useState({ email: "", password: "" });
  const [msg, setMsg] = useState("");
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (data.token) {
        // save in AuthContext
        login(data.token, data.user);

        // redirect based on role
        if (data.user.role === "admin") navigate("/admin/dashboard");
        else if (data.user.role === "mechanic") navigate("/mechanic/dashboard");
        else navigate("/user/dashboard");

        setMsg("Login successful!");
      } else {
        setMsg(data.msg || "Login failed");
      }
    } catch (err) {
      setMsg("Error logging in");
    }
  };

  const goToRegister = () => {
    navigate("/register");
  };

  return (
    <div style={styles.pageContainer}>
      <div style={styles.loginContainer}>
        <div style={styles.loginCard}>
          <h2 style={styles.title}>Welcome Back</h2>
          <p style={styles.subtitle}>Sign in to your account</p>
          
          <form onSubmit={handleSubmit} style={styles.form}>
            <div style={styles.inputGroup}>
              <input 
                name="email" 
                placeholder="Email address" 
                onChange={handleChange}
                style={styles.input}
                type="email"
                required
              />
            </div>
            
            <div style={styles.inputGroup}>
              <input 
                name="password" 
                type="password" 
                placeholder="Password" 
                onChange={handleChange}
                style={styles.input}
                required
              />
            </div>
            
            <button type="submit" style={styles.loginButton}>
              Sign In
            </button>
          </form>

          {msg && (
            <div style={styles.message}>
              {msg}
            </div>
          )}

          <div style={styles.divider}>
            <span style={styles.dividerText}>New to our platform?</span>
          </div>

          <button 
            type="button" 
            onClick={goToRegister} 
            style={styles.registerButton}
          >
            Create an account
          </button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  pageContainer: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f5f5f5',
    padding: '20px',
  },
  loginContainer: {
    width: '100%',
    maxWidth: '400px',
  },
  loginCard: {
    backgroundColor: 'white',
    padding: '40px',
    borderRadius: '12px',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    border: '1px solid #e1e5e9',
  },
  title: {
    textAlign: 'center',
    margin: '0 0 8px 0',
    fontSize: '28px',
    fontWeight: '700',
    color: '#1a202c',
  },
  subtitle: {
    textAlign: 'center',
    margin: '0 0 32px 0',
    color: '#718096',
    fontSize: '14px',
  },
  form: {
    width: '100%',
  },
  inputGroup: {
    marginBottom: '20px',
  },
  input: {
    width: '100%',
    padding: '12px 16px',
    border: '1px solid #e2e8f0',
    borderRadius: '8px',
    fontSize: '14px',
    boxSizing: 'border-box',
    transition: 'all 0.2s ease',
    outline: 'none',
  },
  inputFocus: {
    borderColor: '#3182ce',
    boxShadow: '0 0 0 3px rgba(49, 130, 206, 0.1)',
  },
  loginButton: {
    width: '100%',
    padding: '12px 16px',
    backgroundColor: '#3182ce',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'background-color 0.2s ease',
    marginBottom: '20px',
  },
  registerButton: {
    width: '100%',
    padding: '12px 16px',
    backgroundColor: 'transparent',
    color: '#3182ce',
    border: '1px solid #3182ce',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
  },
  message: {
    padding: '12px',
    borderRadius: '8px',
    textAlign: 'center',
    marginBottom: '20px',
    fontSize: '14px',
    backgroundColor: '#fed7d7',
    color: '#c53030',
    border: '1px solid #feb2b2',
  },
  divider: {
    position: 'relative',
    textAlign: 'center',
    margin: '24px 0',
  },
  dividerText: {
    backgroundColor: 'white',
    padding: '0 12px',
    color: '#718096',
    fontSize: '12px',
  },
};

// Add hover effects
styles.input[':focus'] = styles.inputFocus;
styles.loginButton[':hover'] = { backgroundColor: '#2c5aa0' };
styles.registerButton[':hover'] = { 
  backgroundColor: '#3182ce', 
  color: 'white' 
};

export default Login;

















// import { useNavigate } from "react-router-dom";
// import React, { useState, useContext } from "react";
// import { AuthContext } from "../context/AuthContext";

// const Login = () => {
//   const [form, setForm] = useState({ email: "", password: "" });
//   const [msg, setMsg] = useState("");
//   const { login } = useContext(AuthContext);
//   const navigate = useNavigate();

//   const handleChange = (e) =>
//     setForm({ ...form, [e.target.name]: e.target.value });

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const res = await fetch("/api/auth/login", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(form),
//       });
//       const data = await res.json();
//       if (data.token) {
//         // save in AuthContext
//         login(data.token, data.user);

//         // redirect based on role
//         if (data.user.role === "admin") navigate("/admin/dashboard");
//         else if (data.user.role === "mechanic") navigate("/mechanic/dashboard");
//         else navigate("/user/dashboard");

//         setMsg("Login successful!");
//       } else {
//         setMsg(data.msg || "Login failed");
//       }
//     } catch (err) {
//       setMsg("Error logging in");
//     }
//   };

//   const goToRegister = () => {
//     navigate("/register");
//   };

//   return (
//     <div style={{ padding: 20 }}>
//       <h2>Login</h2>
//       <form onSubmit={handleSubmit}>
//         <input name="email" placeholder="Email" onChange={handleChange} /><br />
//         <input name="password" type="password" placeholder="Password" onChange={handleChange} /><br />
//         <button type="submit">Login</button>
//         <button type="button" onClick={goToRegister} style={{ marginLeft: 10 }}>
//           Register
//         </button>
//       </form>
//       <p>{msg}</p>
//     </div>
//   );
// }

// export default Login;