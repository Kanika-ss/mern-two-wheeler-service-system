import { useNavigate } from "react-router-dom";
import React, { useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";

const Login = () => {
  const [form, setForm] = useState({ email: "", password: "" });
  const [msg, setMsg] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setMsg("");
    
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      
      if (data.token) {
        // save in AuthContext
        login(data.token, data.user);

        // redirect based on role
        if (data.user.role === "admin") navigate("/admin/dashboard");
        else if (data.user.role === "mechanic") navigate("/mechanic/dashboard");
        else navigate("/user/dashboard");

        setMsg("Login successful!");
      } else {
        setMsg(data.msg || "Login failed. Please check your credentials.");
      }
    } catch (err) {
      setMsg("Network error. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const goToRegister = () => {
    navigate("/register");
  };

  return (
    <div style={styles.pageContainer}>
      <div style={styles.backgroundSection}>
        <div style={styles.heroContent}>
          <div style={styles.logoSection}>
            <div style={styles.logoCircle}>
              <span style={styles.logoIcon}>🏍️</span>
            </div>
            <h1 style={styles.heroTitle}>Two Wheeler Service</h1>
            <p style={styles.heroSubtitle}>
              Professional maintenance and repair services for your two-wheeler
            </p>
          </div>
          <div style={styles.featuresList}>
            <div style={styles.featureItem}>
              <span style={styles.featureIcon}>⚡</span>
              Quick Service Booking
            </div>
            <div style={styles.featureItem}>
              <span style={styles.featureIcon}>🔧</span>
              Expert Mechanics
            </div>
            <div style={styles.featureItem}>
              <span style={styles.featureIcon}>🚚</span>
              Free Pickup & Delivery
            </div>
          </div>
        </div>
      </div>

      <div style={styles.loginSection}>
        <div style={styles.loginContainer}>
          <div style={styles.loginCard}>
            <div style={styles.loginHeader}>
              <h2 style={styles.title}>Welcome Back</h2>
              <p style={styles.subtitle}>Sign in to your account to continue</p>
            </div>
            
            <form onSubmit={handleSubmit} style={styles.form}>
              <div style={styles.inputGroup}>
                <label style={styles.label}>Email Address</label>
                <input 
                  name="email" 
                  placeholder="Enter your email" 
                  onChange={handleChange}
                  style={styles.input}
                  type="email"
                  required
                  disabled={isLoading}
                />
              </div>
              
              <div style={styles.inputGroup}>
                <div style={styles.passwordHeader}>
                  <label style={styles.label}>Password</label>
                  
                </div>
                <input 
                  name="password" 
                  type="password" 
                  placeholder="Enter your password" 
                  onChange={handleChange}
                  style={styles.input}
                  required
                  disabled={isLoading}
                />
              </div>
              
              <button 
                type="submit" 
                style={{
                  ...styles.loginButton,
                  ...(isLoading ? styles.loginButtonDisabled : {})
                }}
                disabled={isLoading}
              >
                {isLoading ? (
                  <div style={styles.loadingContainer}>
                    <div style={styles.loadingSpinner}></div>
                    Signing In...
                  </div>
                ) : (
                  "Sign In"
                )}
              </button>
            </form>

            {msg && (
              <div style={
                msg.includes("successful") ? styles.successMessage : styles.errorMessage
              }>
                {msg}
              </div>
            )}

            <div style={styles.divider}>
              <span style={styles.dividerLine}></span>
              <span style={styles.dividerText}>New to our platform?</span>
              <span style={styles.dividerLine}></span>
            </div>

            <button 
              type="button" 
              onClick={goToRegister} 
              style={styles.registerButton}
              disabled={isLoading}
            >
              Create an account
            </button>

            <div style={styles.demoAccounts}>
              <p style={styles.demoTitle}>Demo Accounts:</p>
              <div style={styles.demoGrid}>
                <div style={styles.demoAccount}>
                  <strong>Admin:</strong> admin@example.com / admin123
                </div>
                <div style={styles.demoAccount}>
                  <strong>Mechanic:</strong> mechanic@example.com / mechanic123
                </div>
                <div style={styles.demoAccount}>
                  <strong>User:</strong> user@example.com / user123
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  pageContainer: {
    minHeight: '100vh',
    display: 'flex',
    backgroundColor: '#ffffff',
    fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
  },
  backgroundSection: {
    flex: 1,
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '2rem',
    color: 'white',
    position: 'relative',
    overflow: 'hidden',
  },
  heroContent: {
    maxWidth: '500px',
    textAlign: 'center',
    zIndex: 2,
  },
  logoSection: {
    marginBottom: '3rem',
  },
  logoCircle: {
    width: '80px',
    height: '80px',
    borderRadius: '50%',
    background: 'rgba(255, 255, 255, 0.2)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    margin: '0 auto 1.5rem',
    backdropFilter: 'blur(10px)',
  },
  logoIcon: {
    fontSize: '2.5rem',
  },
  heroTitle: {
    fontSize: '2.5rem',
    fontWeight: '700',
    margin: '0 0 1rem 0',
    background: 'linear-gradient(135deg, #fff, #e2e8f0)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
  },
  heroSubtitle: {
    fontSize: '1.125rem',
    opacity: 0.9,
    lineHeight: 1.6,
    margin: 0,
  },
  featuresList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
  },
  featureItem: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '0.75rem',
    fontSize: '1rem',
    opacity: 0.9,
  },
  featureIcon: {
    fontSize: '1.25rem',
  },
  loginSection: {
    flex: '0 0 480px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '2rem',
    background: '#f8fafc',
  },
  loginContainer: {
    width: '100%',
    maxWidth: '400px',
  },
  loginCard: {
    backgroundColor: 'white',
    padding: '2.5rem',
    borderRadius: '16px',
    boxShadow: '0 10px 25px rgba(0, 0, 0, 0.05)',
    border: '1px solid #e2e8f0',
  },
  loginHeader: {
    textAlign: 'center',
    marginBottom: '2rem',
  },
  title: {
    margin: '0 0 0.5rem 0',
    fontSize: '1.75rem',
    fontWeight: '700',
    color: '#1e293b',
  },
  subtitle: {
    margin: 0,
    color: '#64748b',
    fontSize: '0.875rem',
  },
  form: {
    width: '100%',
  },
  inputGroup: {
    marginBottom: '1.5rem',
  },
  label: {
    display: 'block',
    marginBottom: '0.5rem',
    fontSize: '0.875rem',
    fontWeight: '500',
    color: '#374151',
  },
  passwordHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '0.5rem',
  },
 
  input: {
    width: '100%',
    padding: '0.875rem 1rem',
    border: '1px solid #d1d5db',
    borderRadius: '8px',
    fontSize: '0.875rem',
    boxSizing: 'border-box',
    transition: 'all 0.2s ease',
    outline: 'none',
    backgroundColor: '#fff',
  },
  inputFocus: {
    borderColor: '#3b82f6',
    boxShadow: '0 0 0 3px rgba(59, 130, 246, 0.1)',
  },
  loginButton: {
    width: '100%',
    padding: '0.875rem 1rem',
    backgroundColor: '#3b82f6',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '0.875rem',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    marginBottom: '1.5rem',
  },
  loginButtonDisabled: {
    backgroundColor: '#9ca3af',
    cursor: 'not-allowed',
  },
  loadingContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '0.5rem',
  },
  loadingSpinner: {
    width: '16px',
    height: '16px',
    border: '2px solid transparent',
    borderTop: '2px solid currentColor',
    borderRadius: '50%',
    animation: 'spin 1s linear infinite',
  },
  errorMessage: {
    padding: '0.875rem 1rem',
    borderRadius: '8px',
    textAlign: 'center',
    marginBottom: '1.5rem',
    fontSize: '0.875rem',
    backgroundColor: '#fef2f2',
    color: '#dc2626',
    border: '1px solid #fecaca',
  },
  successMessage: {
    padding: '0.875rem 1rem',
    borderRadius: '8px',
    textAlign: 'center',
    marginBottom: '1.5rem',
    fontSize: '0.875rem',
    backgroundColor: '#f0fdf4',
    color: '#16a34a',
    border: '1px solid #bbf7d0',
  },
  divider: {
    display: 'flex',
    alignItems: 'center',
    margin: '1.5rem 0',
    gap: '1rem',
  },
  dividerLine: {
    flex: 1,
    height: '1px',
    backgroundColor: '#e2e8f0',
  },
  dividerText: {
    color: '#64748b',
    fontSize: '0.75rem',
    fontWeight: '500',
    whiteSpace: 'nowrap',
  },
  registerButton: {
    width: '100%',
    padding: '0.875rem 1rem',
    backgroundColor: 'transparent',
    color: '#374151',
    border: '1px solid #d1d5db',
    borderRadius: '8px',
    fontSize: '0.875rem',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
  },
  demoAccounts: {
    marginTop: '2rem',
    padding: '1rem',
    backgroundColor: '#f8fafc',
    borderRadius: '8px',
    border: '1px solid #e2e8f0',
  },
  demoTitle: {
    margin: '0 0 0.75rem 0',
    fontSize: '0.75rem',
    fontWeight: '600',
    color: '#64748b',
    textAlign: 'center',
  },
  demoGrid: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.5rem',
  },
  demoAccount: {
    fontSize: '0.7rem',
    color: '#475569',
    textAlign: 'center',
    lineHeight: 1.4,
  },
};

// Add CSS animations
const styleSheet = document.styleSheets[0];
styleSheet.insertRule(`
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`, styleSheet.cssRules.length);

// Add hover effects
styles.input[':hover'] = {
  borderColor: '#9ca3af',
};

styles.input[':focus'] = styles.inputFocus;

styles.loginButton[':hover'] = !styles.loginButtonDisabled && {
  backgroundColor: '#2563eb',
  transform: 'translateY(-1px)',
};

styles.registerButton[':hover'] = {
  backgroundColor: '#3b82f6',
  color: 'white',
  borderColor: '#3b82f6',
};


export default Login;