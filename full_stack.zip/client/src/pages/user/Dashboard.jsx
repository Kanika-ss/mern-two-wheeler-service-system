import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../../context/AuthContext';
import api from '../../services/api';
import { useNavigate } from 'react-router-dom';

const UserDashboard = () => {
  const { user } = useContext(AuthContext);
  const [form, setForm] = useState({
    bikeModel: '',
    bikeBrand: '',
    registrationNumber: '',
    serviceType: 'General Service',
    preferredDate: '',
    preferredTime: '',
    pickupAddress: '',
    pickupDate: '',
    pickupTime: '',
  });
  const [msg, setMsg] = useState('');
  const [bookings, setBookings] = useState([]);
  const [showProfile, setShowProfile] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [activeTab, setActiveTab] = useState('book-service');
  const navigate = useNavigate();

  // AUTH CHECK
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) navigate('/login');
  }, [navigate]);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const fetchBookings = async () => {
    try {
      const res = await api.get('/api/bookings');
      setBookings(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    // basic validation
    if (!form.bikeModel || !form.bikeBrand || !form.registrationNumber || !form.pickupAddress) {
      setMsg('Please fill all required fields');
      return;
    }

    try {
      if (editingId) {
        const res = await api.put(`/api/bookings/${editingId}`, form);
        setMsg(res.data.msg);
        setEditingId(null);
      } else {
        const res = await api.post('/api/bookings', form);
        setMsg(res.data.msg);
      }

      setForm({
        bikeModel: '',
        bikeBrand: '',
        registrationNumber: '',
        serviceType: 'General Service',
        preferredDate: '',
        preferredTime: '',
        pickupAddress: '',
        pickupDate: '',
        pickupTime: '',
      });
      fetchBookings();
      setActiveTab('my-bookings');
    } catch (err) {
      setMsg(err.response?.data?.msg || 'Error saving booking');
    }
  };

  const handleEdit = (booking) => {
    setEditingId(booking._id);
    setForm({
      bikeModel: booking.bikeModel,
      bikeBrand: booking.bikeBrand,
      registrationNumber: booking.registrationNumber,
      serviceType: booking.serviceType,
      preferredDate: booking.preferredDate?.split('T')[0] || '',
      preferredTime: booking.preferredTime,
      pickupAddress: booking.pickupAddress || '',
      pickupDate: booking.pickupDate?.split('T')[0] || '',
      pickupTime: booking.pickupTime || '',
    });
    setActiveTab('book-service');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this booking?')) return;
    try {
      const res = await api.delete(`/api/bookings/${id}`);
      setMsg(res.data.msg);
      fetchBookings();
    } catch (err) {
      setMsg(err.response?.data?.msg || 'Error deleting booking');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  const getStatusColor = (status) => {
    const statusColors = {
      'pending': '#f59e0b',
      'confirmed': '#3b82f6',
      'in-progress': '#8b5cf6',
      'completed': '#10b981',
      'cancelled': '#ef4444'
    };
    return statusColors[status?.toLowerCase()] || '#6b7280';
  };

  const getStatusText = (status) => {
    const statusMap = {
      'pending': 'Pending',
      'confirmed': 'Confirmed',
      'in-progress': 'In Progress',
      'completed': 'Completed',
      'cancelled': 'Cancelled'
    };
    return statusMap[status?.toLowerCase()] || status;
  };

  // In the UserDashboard component, add this debugging function
  const debugBookings = () => {
    console.log('All bookings data:', bookings);
    bookings.forEach((booking, index) => {
        console.log(`Booking ${index}:`, {
        id: booking._id,
        assignedMechanic: booking.assignedMechanic,
        mechanicName: booking.assignedMechanic?.name,
        allBookingFields: Object.keys(booking)
        });
    });
  };

    // Add a temporary debug button in your component (remove after debugging)
    <button onClick={debugBookings} style={{background: '#666', color: 'white', padding: '5px 10px', marginBottom: '10px'}}>
    Debug Bookings Data
    </button>

  const canEditBooking = (booking) => {
    return booking.status?.toLowerCase() === 'pending';
  };

  return (
    <div style={styles.pageContainer}>
      {/* Header */}
      <header style={styles.header}>
        <div style={styles.headerLeft}>
          <div style={styles.logoSection}>
            <img src="/images/logo.png" alt="Logo" style={styles.logo} />
            <h2 style={styles.logoText}>Two Wheeler Service</h2>
          </div>
          <nav style={styles.nav}>
            <button 
              style={{...styles.navButton, ...(activeTab === 'book-service' ? styles.navButtonActive : {})}}
              onClick={() => setActiveTab('book-service')}
            >
              Book Service
            </button>
            <button 
              style={{...styles.navButton, ...(activeTab === 'my-bookings' ? styles.navButtonActive : {})}}
              onClick={() => setActiveTab('my-bookings')}
            >
              My Bookings
            </button>
          </nav>
        </div>
        <div style={styles.headerRight}>
          <div style={styles.userInfo}>
            <span style={styles.userName}>Hello, {user?.name}</span>
          </div>
          <button style={styles.profileButton} onClick={() => setShowProfile(true)}>
            Profile
          </button>
          <button style={styles.logoutButton} onClick={handleLogout}>
            Logout
          </button>
        </div>
      </header>

      {/* Main Content */}
      <div style={styles.content}>
        {/* Welcome Section */}
        <div style={styles.welcomeSection}>
          <h1 style={styles.welcomeTitle}>
            {activeTab === 'book-service' ? 'Book Your Service' : 'Your Bookings'}
          </h1>
          <p style={styles.welcomeSubtitle}>
            {activeTab === 'book-service' 
              ? 'Schedule your two-wheeler service with ease' 
              : 'Track and manage all your service requests'
            }
          </p>
        </div>

        {/* Message Display */}
        {msg && (
          <div style={msg.includes('Error') ? styles.errorAlert : styles.successAlert}>
            {msg}
            <button style={styles.alertClose} onClick={() => setMsg('')}>×</button>
          </div>
        )}

        {/* Book Service Tab */}
        {activeTab === 'book-service' && (
          <div style={styles.tabContent}>
            <div style={styles.card}>
              <div style={styles.cardHeader}>
                <h3 style={styles.cardTitle}>
                  {editingId ? 'Edit Booking' : 'New Service Request'}
                </h3>
                {editingId && (
                  <button 
                    style={styles.secondaryButton}
                    onClick={() => {
                      setEditingId(null);
                      setForm({
                        bikeModel: '',
                        bikeBrand: '',
                        registrationNumber: '',
                        serviceType: 'General Service',
                        preferredDate: '',
                        preferredTime: '',
                        pickupAddress: '',
                        pickupDate: '',
                        pickupTime: '',
                      });
                    }}
                  >
                    Cancel Edit
                  </button>
                )}
              </div>
              
              <form onSubmit={handleSubmit} style={styles.form}>
                <div style={styles.formGrid}>
                  <div style={styles.formGroup}>
                    <label style={styles.label}>Bike Brand *</label>
                    <input 
                      name="bikeBrand" 
                      value={form.bikeBrand} 
                      onChange={handleChange} 
                      placeholder="e.g., Honda, Yamaha" 
                      style={styles.input}
                      required
                    />
                  </div>
                  
                  <div style={styles.formGroup}>
                    <label style={styles.label}>Bike Model *</label>
                    <input 
                      name="bikeModel" 
                      value={form.bikeModel} 
                      onChange={handleChange} 
                      placeholder="e.g., Activa, Pulsar" 
                      style={styles.input}
                      required
                    />
                  </div>
                </div>

                <div style={styles.formGrid}>
                  <div style={styles.formGroup}>
                    <label style={styles.label}>Registration Number *</label>
                    <input 
                      name="registrationNumber" 
                      value={form.registrationNumber} 
                      onChange={handleChange} 
                      placeholder="e.g., KA01AB1234" 
                      style={styles.input}
                      required
                    />
                  </div>
                  
                  <div style={styles.formGroup}>
                    <label style={styles.label}>Service Type *</label>
                    <select name="serviceType" value={form.serviceType} onChange={handleChange} style={styles.input}>
                      <option>General Service</option>
                      <option>Oil Change</option>
                      <option>Repair</option>
                      <option>Battery Replacement</option>
                      <option>Tyre Service</option>
                    </select>
                  </div>
                </div>

                <div style={styles.formGroup}>
                  <label style={styles.label}>Pickup Address *</label>
                  <input 
                    name="pickupAddress" 
                    value={form.pickupAddress} 
                    onChange={handleChange} 
                    placeholder="Enter complete pickup address" 
                    style={styles.input}
                    required
                  />
                </div>

                <div style={styles.formGrid}>
                  <div style={styles.formGroup}>
                    <label style={styles.label}>Pickup Date *</label>
                    <input 
                      type="date" 
                      name="pickupDate" 
                      value={form.pickupDate} 
                      onChange={handleChange} 
                      style={styles.input}
                      required
                    />
                  </div>
                  
                  <div style={styles.formGroup}>
                    <label style={styles.label}>Pickup Time *</label>
                    <input 
                      type="time" 
                      name="pickupTime" 
                      value={form.pickupTime} 
                      onChange={handleChange} 
                      style={styles.input}
                      required
                    />
                  </div>
                </div>

                <div style={styles.formGrid}>
                  <div style={styles.formGroup}>
                    <label style={styles.label}>Preferred Delivery Date</label>
                    <input 
                      type="date" 
                      name="preferredDate" 
                      value={form.preferredDate} 
                      onChange={handleChange} 
                      style={styles.input}
                    />
                  </div>
                  
                  <div style={styles.formGroup}>
                    <label style={styles.label}>Preferred Delivery Time</label>
                    <input 
                      type="time" 
                      name="preferredTime" 
                      value={form.preferredTime} 
                      onChange={handleChange} 
                      style={styles.input}
                    />
                  </div>
                </div>

                <button type="submit" style={styles.primaryButton}>
                  {editingId ? 'Update Booking' : 'Book Service Now'}
                </button>
              </form>
            </div>
          </div>
        )}

        {/* My Bookings Tab */}
        {activeTab === 'my-bookings' && (
          <div style={styles.tabContent}>
    <div style={styles.card}>
      <div style={styles.cardHeader}>
        <h3 style={styles.cardTitle}>Service History</h3>
        <span style={styles.badge}>{bookings.length} bookings</span>
      </div>
             {bookings.length === 0 ? (
        <div style={styles.emptyState}>
          <div style={styles.emptyIcon}>🏍️</div>
          <h4>No Bookings Yet</h4>
          <p>You haven't booked any services yet. Schedule your first service!</p>
          <button 
            style={styles.primaryButton}
            onClick={() => setActiveTab('book-service')}
          >
            Book Your First Service
          </button>
        </div>
      ) : (
        <div style={styles.tableContainer}>
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>Bike Details</th>
                <th style={styles.th}>Service Type</th>
                <th style={styles.th}>Pickup Details</th>
                <th style={styles.th}>Status</th>
                <th style={styles.th}>Assigned Mechanic</th>
                <th style={styles.th}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((b) => {
                // Debug logging for each booking
                console.log('Booking:', b._id, 'Mechanic:', b.assignedMechanic);
                
                // Get mechanic name with fallbacks
                const getMechanicName = (booking) => {
                  if (!booking.assignedMechanic) return null;
                  
                  // Try different possible field names
                  return booking.assignedMechanic.name || 
                         booking.assignedMechanic.fullName ||
                         booking.assignedMechanic.username ||
                         `${booking.assignedMechanic.firstName} ${booking.assignedMechanic.lastName}`.trim() ||
                         'Mechanic';
                };
                
                const mechanicName = getMechanicName(b);
                
                return (
                  <tr key={b._id} style={styles.tr}>
                    <td style={styles.td}>
                      <div style={styles.bikeInfo}>
                        <strong>{b.bikeBrand} {b.bikeModel}</strong>
                        <div style={styles.regNumber}>{b.registrationNumber}</div>
                      </div>
                    </td>
                    <td style={styles.td}>
                      <span style={styles.serviceBadge}>{b.serviceType}</span>
                    </td>
                    <td style={styles.td}>
                      <div style={styles.pickupInfo}>
                        <div>{b.pickupAddress}</div>
                        <div style={styles.dateTime}>
                          {new Date(b.pickupDate).toLocaleDateString()} at {b.pickupTime}
                        </div>
                      </div>
                    </td>
                    <td style={styles.td}>
                      <span 
                        style={{
                          ...styles.statusBadge,
                          backgroundColor: getStatusColor(b.status)
                        }}
                      >
                        {getStatusText(b.status)}
                      </span>
                    </td>
                    <td style={styles.td}>
                      {b.assignedMechanic ? (
                        <div style={styles.mechanicInfo}>
                          <strong>{mechanicName}</strong>
                          {b.assignedMechanic.phone && (
                            <div style={styles.mechanicContact}>{b.assignedMechanic.phone}</div>
                          )}
                        </div>
                      ) : (
                        <span style={styles.unassigned}>Not assigned yet</span>
                      )}
                    </td>
                    <td style={styles.td}>
                      {canEditBooking(b) ? (
                        <div style={styles.actionButtons}>
                          <button 
                            onClick={() => handleEdit(b)} 
                            style={styles.editButton}
                          >
                            Edit
                          </button>
                          <button 
                            onClick={() => handleDelete(b._id)} 
                            style={styles.deleteButton}
                          >
                            Delete
                          </button>
                        </div>
                      ) : (
                        <span style={styles.lockedText}>Locked</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Profile Modal */}
      {showProfile && (
        <div style={styles.modalOverlay}>
          <div style={styles.modalContainer}>
            <div style={styles.modalHeader}>
              <h2 style={styles.modalTitle}>Profile Details</h2>
              <button style={styles.modalClose} onClick={() => setShowProfile(false)}>×</button>
            </div>
            <div style={styles.profileDetails}>
              <div style={styles.profileField}>
                <label style={styles.profileLabel}>Full Name</label>
                <div style={styles.profileValue}>{user?.name}</div>
              </div>
              <div style={styles.profileField}>
                <label style={styles.profileLabel}>Email Address</label>
                <div style={styles.profileValue}>{user?.email}</div>
              </div>
              <div style={styles.profileField}>
                <label style={styles.profileLabel}>Phone Number</label>
                <div style={styles.profileValue}>{user?.phone || 'Not provided'}</div>
              </div>
            </div>
            <div style={styles.modalActions}>
              <button style={styles.primaryButton} onClick={() => setShowProfile(false)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const styles = {
  pageContainer: {
    fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    background: '#f8fafc',
    minHeight: '100vh',
    color: '#334155',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '0 2rem',
    background: '#fff',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    borderBottom: '1px solid #e2e8f0',
    height: '70px',
  },
  headerLeft: {
    display: 'flex',
    alignItems: 'center',
    gap: '3rem',
  },
  logoSection: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
  },
  logo: {
    width: '40px',
    height: '40px',
  },
  logoText: {
    margin: 0,
    fontSize: '1.25rem',
    fontWeight: '700',
    color: '#1e293b',
  },
  nav: {
    display: 'flex',
    gap: '0.5rem',
  },
  navButton: {
    padding: '0.5rem 1rem',
    background: 'transparent',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.875rem',
    fontWeight: '500',
    color: '#64748b',
    transition: 'all 0.2s',
  },
  navButtonActive: {
    background: '#3b82f6',
    color: '#fff',
  },
  headerRight: {
    display: 'flex',
    alignItems: 'center',
    gap: '1rem',
  },
  userInfo: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-end',
  },
  userName: {
    fontWeight: '600',
    fontSize: '0.875rem',
    color: '#374151',
  },
  profileButton: {
    padding: '0.5rem 1rem',
    background: 'transparent',
    color: '#374151',
    border: '1px solid #d1d5db',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.875rem',
    fontWeight: '500',
    transition: 'all 0.2s',
  },
  logoutButton: {
    padding: '0.5rem 1rem',
    background: '#ef4444',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.875rem',
    fontWeight: '500',
    transition: 'background 0.2s',
  },
  content: {
    padding: '2rem',
    maxWidth: '1200px',
    margin: '0 auto',
  },
  welcomeSection: {
    marginBottom: '2rem',
  },
  welcomeTitle: {
    fontSize: '2rem',
    fontWeight: '700',
    color: '#1e293b',
    margin: '0 0 0.5rem 0',
  },
  welcomeSubtitle: {
    fontSize: '1.125rem',
    color: '#64748b',
    margin: 0,
  },
  tabContent: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1.5rem',
  },
  card: {
    background: '#fff',
    padding: '1.5rem',
    borderRadius: '12px',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    border: '1px solid #e2e8f0',
  },
  cardHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '1.5rem',
  },
  cardTitle: {
    margin: 0,
    fontSize: '1.25rem',
    fontWeight: '600',
    color: '#1e293b',
  },
  badge: {
    background: '#f1f5f9',
    color: '#475569',
    padding: '0.25rem 0.75rem',
    borderRadius: '20px',
    fontSize: '0.75rem',
    fontWeight: '600',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1.5rem',
  },
  formGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '1rem',
  },
  formGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.5rem',
  },
  label: {
    fontSize: '0.875rem',
    fontWeight: '500',
    color: '#374151',
  },
  input: {
    padding: '0.75rem',
    border: '1px solid #d1d5db',
    borderRadius: '8px',
    fontSize: '0.875rem',
    transition: 'border-color 0.2s, box-shadow 0.2s',
  },
  primaryButton: {
    padding: '0.75rem 1.5rem',
    background: '#3b82f6',
    color: '#fff',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '0.875rem',
    fontWeight: '500',
    transition: 'background 0.2s',
    alignSelf: 'flex-start',
  },
  secondaryButton: {
    padding: '0.75rem 1.5rem',
    background: 'transparent',
    color: '#64748b',
    border: '1px solid #d1d5db',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '0.875rem',
    fontWeight: '500',
    transition: 'all 0.2s',
  },
  emptyState: {
    padding: '3rem 2rem',
    textAlign: 'center',
    color: '#64748b',
  },
  emptyIcon: {
    fontSize: '3rem',
    marginBottom: '1rem',
  },
  tableContainer: {
    overflowX: 'auto',
    borderRadius: '8px',
    border: '1px solid #e2e8f0',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    fontSize: '0.875rem',
  },
  th: {
    background: '#f8fafc',
    padding: '1rem',
    textAlign: 'left',
    fontWeight: '600',
    color: '#374151',
    borderBottom: '1px solid #e2e8f0',
    whiteSpace: 'nowrap',
  },
  tr: {
    borderBottom: '1px solid #e2e8f0',
    transition: 'background 0.2s',
  },
  td: {
    padding: '1rem',
    borderBottom: '1px solid #e2e8f0',
    verticalAlign: 'top',
  },
  bikeInfo: {
    display: 'flex',
    flexDirection: 'column',
  },
  regNumber: {
    fontSize: '0.75rem',
    color: '#64748b',
    marginTop: '0.25rem',
  },
  serviceBadge: {
    background: '#f1f5f9',
    color: '#475569',
    padding: '0.25rem 0.5rem',
    borderRadius: '4px',
    fontSize: '0.75rem',
    fontWeight: '500',
  },
  pickupInfo: {
    display: 'flex',
    flexDirection: 'column',
  },
  dateTime: {
    fontSize: '0.75rem',
    color: '#64748b',
    marginTop: '0.25rem',
  },
  statusBadge: {
    padding: '0.375rem 0.75rem',
    borderRadius: '20px',
    fontSize: '0.75rem',
    fontWeight: '500',
    color: '#fff',
    textTransform: 'capitalize',
  },
  mechanicInfo: {
    fontSize: '0.875rem',
  },
  unassigned: {
    color: '#9ca3af',
    fontStyle: 'italic',
    fontSize: '0.875rem',
  },
  actionButtons: {
    display: 'flex',
    gap: '0.5rem',
  },
  editButton: {
    padding: '0.375rem 0.75rem',
    background: '#3b82f6',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.75rem',
    fontWeight: '500',
  },
  deleteButton: {
    padding: '0.375rem 0.75rem',
    background: '#ef4444',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.75rem',
    fontWeight: '500',
  },
  lockedText: {
    color: '#9ca3af',
    fontSize: '0.875rem',
    fontStyle: 'italic',
  },
  modalOverlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(0,0,0,0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
    padding: '1rem',
  },
  modalContainer: {
    background: '#fff',
    padding: '2rem',
    borderRadius: '12px',
    width: '100%',
    maxWidth: '500px',
    boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)',
  },
  modalHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '1.5rem',
  },
  modalTitle: {
    margin: 0,
    fontSize: '1.5rem',
    fontWeight: '600',
    color: '#1e293b',
  },
  modalClose: {
    background: 'transparent',
    border: 'none',
    fontSize: '1.5rem',
    cursor: 'pointer',
    color: '#64748b',
    padding: 0,
    width: '30px',
    height: '30px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileDetails: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
    marginBottom: '2rem',
  },
  profileField: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.5rem',
  },
  profileLabel: {
    fontSize: '0.875rem',
    fontWeight: '500',
    color: '#374151',
  },
  profileValue: {
    padding: '0.75rem',
    background: '#f8fafc',
    borderRadius: '8px',
    border: '1px solid #e2e8f0',
    fontSize: '0.875rem',
  },
  modalActions: {
    display: 'flex',
    justifyContent: 'flex-end',
  },
  successAlert: {
    background: '#dcfce7',
    color: '#166534',
    padding: '1rem',
    borderRadius: '8px',
    marginBottom: '1.5rem',
    border: '1px solid #bbf7d0',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  errorAlert: {
    background: '#fef2f2',
    color: '#dc2626',
    padding: '1rem',
    borderRadius: '8px',
    marginBottom: '1.5rem',
    border: '1px solid #fecaca',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  alertClose: {
    background: 'transparent',
    border: 'none',
    color: 'inherit',
    fontSize: '1.25rem',
    cursor: 'pointer',
    padding: 0,
    width: '24px',
    height: '24px',
  },
};

export default UserDashboard;