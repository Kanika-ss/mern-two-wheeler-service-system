// import React, { useState, useEffect, useContext, useCallback } from 'react';
// import { AuthContext } from '../../context/AuthContext';
// import api from '../../services/api';

// const MechanicDashboard = () => {
//   const { user, authLoading } = useContext(AuthContext);
//   const [bookings, setBookings] = useState([]);
//   const [updateData, setUpdateData] = useState({
//     bookingId: '',
//     status: '',
//     remarks: '',
//     cost: '',
//   });

//   // fetchBookings is now memoized - hooks must run unconditionally
// const fetchBookings = useCallback(async () => {
//   if (!user) return;
//   try {
//     const res = await api.get('/api/admin/mechanic/bookings'); // new endpoint
//     setBookings(res.data);
//   } catch (err) {
//     console.error('Failed to fetch bookings', err);
//   }
// }, [user]);


//   useEffect(() => {
//     fetchBookings();
//   }, [fetchBookings]);

//   const handleUpdate = async () => {
//     if (!updateData.bookingId || !updateData.status) {
//       alert('Please select booking and status');
//       return;
//     }
//     try {
//       const res = await api.post('/api/admin/update-booking', updateData);
//       alert(res.data.msg);
//       fetchBookings();
//     } catch (err) {
//       alert(err.response?.data?.msg || 'Error updating booking');
//     }
//   };

//   // early return for loading / no user
//   if (authLoading) return <div>Loading...</div>;
//   if (!user) return <div>Please login to view dashboard</div>;

//   return (
//     <div style={{ padding: 20 }}>
//       <h2>Mechanic Dashboard</h2>

//       <h3>Assigned Bookings</h3>
//       {bookings.length === 0 ? (
//         <p>No bookings assigned yet</p>
//       ) : (
//         <table border="1" cellPadding="5">
//           <thead>
//             <tr>
//               <th>Customer</th>
//               <th>Bike</th>
//               <th>Service</th>
//               <th>Date</th>
//               <th>Time</th>
//               <th>Status</th>
//             </tr>
//           </thead>
//           <tbody>
//             {bookings.map(b => (
//               <tr key={b._id}>
//                 <td>{b.user?.name}</td>
//                 <td>{b.bikeBrand} {b.bikeModel}</td>
//                 <td>{b.serviceType}</td>
//                 <td>{new Date(b.preferredDate).toLocaleDateString()}</td>
//                 <td>{b.preferredTime}</td>
//                 <td>{b.status}</td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       )}

//       <h3>Update Booking</h3>
//       <select
//         onChange={e => setUpdateData({ ...updateData, bookingId: e.target.value })}
//       >
//         <option value="">Select Booking</option>
//         {bookings.map(b => (
//           <option key={b._id} value={b._id}>
//             {b.bikeBrand} {b.bikeModel} - {b.user?.name}
//           </option>
//         ))}
//       </select>
//       <select
//         onChange={e => setUpdateData({ ...updateData, status: e.target.value })}
//       >
//         <option value="">Select Status</option>
//         <option>Pending</option>
//         <option>In Progress</option>
//         <option>Completed</option>
//       </select>
//       <input
//         placeholder="Remarks"
//         onChange={e => setUpdateData({ ...updateData, remarks: e.target.value })}
//       /><br />
//       <input
//         placeholder="Cost"
//         type="number"
//         onChange={e => setUpdateData({ ...updateData, cost: e.target.value })}
//       /><br />
//       <button onClick={handleUpdate}>Update Booking</button>
//     </div>
//   );
// };

// export default MechanicDashboard;













import React, { useState, useEffect, useContext, useCallback } from 'react';
import { AuthContext } from '../../context/AuthContext';
import api from '../../services/api';
import { useNavigate } from 'react-router-dom';

const MechanicDashboard = () => {
  const { user, authLoading } = useContext(AuthContext);
  const [bookings, setBookings] = useState([]);
  const [updateData, setUpdateData] = useState({
    bookingId: '',
    status: '',
    remarks: '',
    cost: '',
  });

  const navigate = useNavigate();

  const fetchBookings = useCallback(async () => {
    if (!user) return;
    try {
      const res = await api.get('/api/mechanic/bookings');
      setBookings(res.data);
    } catch (err) {
      console.error('Failed to fetch bookings', err);
    }
  }, [user]);

  useEffect(() => {
    fetchBookings();
  }, [fetchBookings]);

  const handleUpdate = async () => {
    if (!updateData.bookingId || !updateData.status) {
      alert('Please select booking and status');
      return;
    }
    try {
      const res = await api.post('/api/mechanic/update', updateData);
      alert(res.data.msg);
      fetchBookings();
      setUpdateData({ bookingId: '', status: '', remarks: '', cost: '' });
    } catch (err) {
      alert(err.response?.data?.msg || 'Error updating booking');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  if (authLoading) return <div>Loading...</div>;
  if (!user) return <div>Please login to view dashboard</div>;

  return (
    <div style={styles.pageContainer}>
      {/* Header */}
      <header style={styles.header}>
        <div style={styles.logoSection}>
          <img src="/images/logo.png" alt="Logo" style={styles.logo} />
          <h2 style={{ margin: 0 }}>Two Wheeler Service</h2>
        </div>
        <nav style={styles.nav}>
          <span style={styles.navItem}>Profile</span>
          <span style={styles.navItem} onClick={handleLogout}>
            Logout
          </span>
        </nav>
      </header>

      {/* Main Content */}
      <div style={styles.content}>
        <h2>Welcome, {user?.name}</h2>
        <p style={styles.description}>
          View your assigned bookings and update their service status.
        </p>

        {/* Assigned Bookings */}
        <div style={styles.tableCard}>
          <h3>Assigned Bookings</h3>
          {bookings.length === 0 ? (
            <p>No bookings assigned yet.</p>
          ) : (
            <table style={styles.table}>
              <thead>
                <tr>
                  <th style={styles.th}>Customer</th>
                  <th style={styles.th}>Bike</th>
                  <th style={styles.th}>Service</th>
                  <th style={styles.th}>Date</th>
                  <th style={styles.th}>Time</th>
                  <th style={styles.th}>Status</th>
                </tr>
              </thead>
              <tbody>
                {bookings.map((b) => (
                  <tr key={b._id} style={styles.trHover}>
                    <td style={styles.td}>{b.user?.name}</td>
                    <td style={styles.td}>
                      {b.bikeBrand} {b.bikeModel}
                    </td>
                    <td style={styles.td}>{b.serviceType}</td>
                    <td style={styles.td}>
                      {new Date(b.deliveryDate).toLocaleDateString()}
                    </td>
                    <td style={styles.td}>{b.deliveryTime}</td>
                    <td style={styles.td}>{b.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Update Booking */}
        <div style={styles.formCard}>
          <h3>Update Booking Status</h3>
          <div style={styles.form}>
            <label style={styles.label}>Select Booking</label>
            <select
              value={updateData.bookingId}
              onChange={(e) =>
                setUpdateData({ ...updateData, bookingId: e.target.value })
              }
              style={styles.input}
            >
              <option value="">Select Booking</option>
              {bookings.map((b) => (
                <option key={b._id} value={b._id}>
                  {b.bikeBrand} {b.bikeModel} - {b.user?.name}
                </option>
              ))}
            </select>

            <label style={styles.label}>Select Status</label>
            <select
              value={updateData.status}
              onChange={(e) =>
                setUpdateData({ ...updateData, status: e.target.value })
              }
              style={styles.input}
            >
              <option value="">Select Status</option>
              <option>Pending</option>
              <option>In Progress</option>
              <option>Completed</option>
            </select>

            <label style={styles.label}>Remarks</label>
            <input
              placeholder="Remarks"
              value={updateData.remarks}
              onChange={(e) =>
                setUpdateData({ ...updateData, remarks: e.target.value })
              }
              style={styles.input}
            />

            <label style={styles.label}>Cost</label>
            <input
              placeholder="Cost"
              type="number"
              value={updateData.cost}
              onChange={(e) =>
                setUpdateData({ ...updateData, cost: e.target.value })
              }
              style={styles.input}
            />

            <button onClick={handleUpdate} style={styles.submitButton}>
              Update Booking
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const styles = {
  pageContainer: {
    fontFamily: 'Arial, sans-serif',
    background: '#f5f5f5',
    minHeight: '100vh',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    background: '#333',
    color: '#fff',
  },
  logoSection: {
    display: 'flex',
    alignItems: 'center',
  },
  logo: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
  nav: {
    display: 'flex',
    gap: 20,
  },
  navItem: {
    cursor: 'pointer',
    textDecoration: 'underline',
  },
  content: {
    padding: '30px 60px',
  },
  description: {
    fontSize: 16,
    marginBottom: 20,
  },
  formCard: {
    background: '#fff',
    padding: 20,
    borderRadius: 8,
    marginBottom: 30,
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
  },
  tableCard: {
    background: '#fff',
    padding: 20,
    borderRadius: 8,
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
    marginBottom: 30,
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
  },
  input: {
    display: 'block',
    width: '98%',
    padding: 10,
    marginBottom: 10,
    borderRadius: 4,
    border: '1px solid #ccc',
  },
  label: {
    fontWeight: 'bold',
    marginBottom: 5,
    marginTop: 10,
    color: '#333',
    fontSize: 14,
  },
  submitButton: {
    padding: '10px 20px',
    background: '#333',
    color: '#fff',
    border: 'none',
    borderRadius: 4,
    cursor: 'pointer',
    marginTop: 10,
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    textAlign: 'center',
  },
  th: {
    background: '#333',
    color: '#fff',
    padding: '12px 8px',
    borderBottom: '2px solid #444',
  },
  td: {
    padding: '10px 8px',
    borderBottom: '1px solid #ddd',
  },
  trHover: {
    backgroundColor: '#f9f9f9',
  },
};

export default MechanicDashboard;
