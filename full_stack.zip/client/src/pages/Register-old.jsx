import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Register() {
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [msg, setMsg] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      setMsg(data.msg || JSON.stringify(data));

      if (res.ok) {
      setForm({ name: "", email: "", password: "" });
    }
    } catch (err) {
      setMsg("Error registering");
    }
  };

  const goToLogin = () => {
    navigate("/login");
  };

  return (
    <div style={styles.pageContainer}>
      <div style={styles.registerContainer}>
        <div style={styles.registerCard}>
          <h2 style={styles.title}>Create Account</h2>
          <p style={styles.subtitle}>Join us and get started</p>
          
          <form onSubmit={handleSubmit} style={styles.form}>
            <div style={styles.inputGroup}>
              <input 
                name="name" 
                placeholder="Full Name" 
                onChange={handleChange}
                value={form.name} 
                style={styles.input}
                required
              />
            </div>
            
            <div style={styles.inputGroup}>
              <input 
                name="email" 
                type="email" 
                placeholder="Email address" 
                onChange={handleChange}
                value={form.email}
                style={styles.input}
                required
              />
            </div>
            
            <div style={styles.inputGroup}>
              <input 
                name="password" 
                type="password" 
                placeholder="Password" 
                onChange={handleChange}
                value={form.password}
                style={styles.input}
                required
              />
            </div>
            
            <button type="submit" style={styles.registerButton}>
              Create Account
            </button>
          </form>

          {msg && (
            <div style={msg.includes("Error") || msg.includes("failed") ? styles.errorMessage : styles.successMessage}>
              {msg}
            </div>
          )}

          <div style={styles.divider}>
            <span style={styles.dividerText}>Already have an account?</span>
          </div>

          <button 
            type="button" 
            onClick={goToLogin} 
            style={styles.loginButton}
          >
            Sign In
          </button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  pageContainer: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f5f5f5',
    padding: '20px',
  },
  registerContainer: {
    width: '100%',
    maxWidth: '400px',
  },
  registerCard: {
    backgroundColor: 'white',
    padding: '40px',
    borderRadius: '12px',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    border: '1px solid #e1e5e9',
  },
  title: {
    textAlign: 'center',
    margin: '0 0 8px 0',
    fontSize: '28px',
    fontWeight: '700',
    color: '#1a202c',
  },
  subtitle: {
    textAlign: 'center',
    margin: '0 0 32px 0',
    color: '#718096',
    fontSize: '14px',
  },
  form: {
    width: '100%',
  },
  inputGroup: {
    marginBottom: '20px',
  },
  input: {
    width: '100%',
    padding: '12px 16px',
    border: '1px solid #e2e8f0',
    borderRadius: '8px',
    fontSize: '14px',
    boxSizing: 'border-box',
    transition: 'all 0.2s ease',
    outline: 'none',
  },
  registerButton: {
    width: '100%',
    padding: '12px 16px',
    backgroundColor: '#3182ce',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'background-color 0.2s ease',
    marginBottom: '20px',
  },
  loginButton: {
    width: '100%',
    padding: '12px 16px',
    backgroundColor: 'transparent',
    color: '#3182ce',
    border: '1px solid #3182ce',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
  },
  errorMessage: {
    padding: '12px',
    borderRadius: '8px',
    textAlign: 'center',
    marginBottom: '20px',
    fontSize: '14px',
    backgroundColor: '#fed7d7',
    color: '#c53030',
    border: '1px solid #feb2b2',
  },
  successMessage: {
    padding: '12px',
    borderRadius: '8px',
    textAlign: 'center',
    marginBottom: '20px',
    fontSize: '14px',
    backgroundColor: '#c6f6d5',
    color: '#2d5016',
    border: '1px solid #9ae6b4',
  },
  divider: {
    position: 'relative',
    textAlign: 'center',
    margin: '24px 0',
    '&::before': {
      content: '""',
      position: 'absolute',
      top: '50%',
      left: '0',
      right: '0',
      height: '1px',
      backgroundColor: '#e2e8f0',
      zIndex: '1',
    },
  },
  dividerText: {
    backgroundColor: 'white',
    padding: '0 12px',
    color: '#718096',
    fontSize: '12px',
    position: 'relative',
    zIndex: '2',
  },
};

styles.input[':focus'] = {
  borderColor: '#3182ce',
  boxShadow: '0 0 0 3px rgba(49, 130, 206, 0.1)',
};

styles.registerButton[':hover'] = { 
  backgroundColor: '#2c5aa0' 
};

styles.loginButton[':hover'] = { 
  backgroundColor: '#3182ce', 
  color: 'white' 
};

export default Register;










// import React, { useState } from "react";
// import { useNavigate } from "react-router-dom";

// function Register() {
//   const [form, setForm] = useState({ name: "", email: "", password: "" });
//   const [msg, setMsg] = useState("");
//   const navigate = useNavigate();

//   const handleChange = (e) =>
//     setForm({ ...form, [e.target.name]: e.target.value });

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const res = await fetch("/api/auth/register", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(form),
//       });
//       const data = await res.json();
//       setMsg(data.msg || JSON.stringify(data));
//     } catch (err) {
//       setMsg("Error registering");
//     }
//   };

//   const goToLogin = () => {
//     navigate("/login");
//   };

//   return (
//     <div style={{ padding: 20 }}>
//       <h2>Register</h2>
//       <form onSubmit={handleSubmit}>
//         <input name="name" placeholder="Name" onChange={handleChange} /><br />
//         <input name="email" type="email" placeholder="Email" onChange={handleChange} /><br />
//         <input name="password" type="password" placeholder="Password" onChange={handleChange} /><br />
//         <button type="submit">Register</button>
//         <button type="button" onClick={goToLogin} style={{ marginLeft: 10 }}>
//           Back to Login
//         </button>
//       </form>
//       <p>{msg}</p>
//     </div>
//   );
// }

// export default Register;
