import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Register() {
  const [form, setForm] = useState({ 
    name: "", 
    email: "", 
    password: "",
    phone: "",
    confirmPassword: ""
  });
  const [msg, setMsg] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    // Clear error when user starts typing
    if (errors[e.target.name]) {
      setErrors({ ...errors, [e.target.name]: "" });
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!form.name.trim()) {
      newErrors.name = "Full name is required";
    }
    
    if (!form.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      newErrors.email = "Email is invalid";
    }
    
    if (!form.phone.trim()) {
      newErrors.phone = "Phone number is required";
    }
    
    if (!form.password) {
      newErrors.password = "Password is required";
    } else if (form.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters";
    }
    
    if (!form.confirmPassword) {
      newErrors.confirmPassword = "Please confirm your password";
    } else if (form.password !== form.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMsg("");
    
    if (!validateForm()) {
      return;
    }
    
    setIsLoading(true);
    
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          password: form.password,
          phone: form.phone
        }),
      });
      const data = await res.json();
      
      if (res.ok) {
        setMsg(data.msg || "Registration successful! Redirecting to login...");
        setForm({ name: "", email: "", password: "", phone: "", confirmPassword: "" });
        
        // Redirect to login after successful registration
        setTimeout(() => {
          navigate("/login");
        }, 2000);
      } else {
        setMsg(data.msg || "Registration failed. Please try again.");
      }
    } catch (err) {
      setMsg("Network error. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const goToLogin = () => {
    navigate("/login");
  };

  return (
    <div style={styles.pageContainer}>
      <div style={styles.backgroundSection}>
        <div style={styles.heroContent}>
          <div style={styles.logoSection}>
            <div style={styles.logoCircle}>
              <span style={styles.logoIcon}>🏍️</span>
            </div>
            <h1 style={styles.heroTitle}>Two Wheeler Service</h1>
            <p style={styles.heroSubtitle}>
              Join thousands of satisfied customers who trust us with their two-wheelers
            </p>
          </div>
          <div style={styles.benefitsList}>
            <div style={styles.benefitItem}>
              <span style={styles.benefitIcon}>✅</span>
              Easy Service Booking
            </div>
            <div style={styles.benefitItem}>
              <span style={styles.benefitIcon}>✅</span>
              Expert Mechanics
            </div>
            <div style={styles.benefitItem}>
              <span style={styles.benefitIcon}>✅</span>
              Doorstep Pickup & Delivery
            </div>
            <div style={styles.benefitItem}>
              <span style={styles.benefitIcon}>✅</span>
              Transparent Pricing
            </div>
          </div>
        </div>
      </div>

      <div style={styles.registerSection}>
        <div style={styles.registerContainer}>
          <div style={styles.registerCard}>
            <div style={styles.registerHeader}>
              <h2 style={styles.title}>Create Account</h2>
              <p style={styles.subtitle}>Join our community today</p>
            </div>
            
            <form onSubmit={handleSubmit} style={styles.form}>
              <div style={styles.inputGroup}>
                <label style={styles.label}>Full Name *</label>
                <input 
                  name="name" 
                  placeholder="Enter your full name" 
                  onChange={handleChange}
                  value={form.name} 
                  style={{
                    ...styles.input,
                    ...(errors.name ? styles.inputError : {})
                  }}
                  required
                  disabled={isLoading}
                />
                {errors.name && <span style={styles.errorText}>{errors.name}</span>}
              </div>
              
              <div style={styles.inputGroup}>
                <label style={styles.label}>Email Address *</label>
                <input 
                  name="email" 
                  type="email" 
                  placeholder="Enter your email address" 
                  onChange={handleChange}
                  value={form.email}
                  style={{
                    ...styles.input,
                    ...(errors.email ? styles.inputError : {})
                  }}
                  required
                  disabled={isLoading}
                />
                {errors.email && <span style={styles.errorText}>{errors.email}</span>}
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Phone Number *</label>
                <input 
                  name="phone" 
                  type="tel" 
                  placeholder="Enter your phone number" 
                  onChange={handleChange}
                  value={form.phone}
                  style={{
                    ...styles.input,
                    ...(errors.phone ? styles.inputError : {})
                  }}
                  required
                  disabled={isLoading}
                />
                {errors.phone && <span style={styles.errorText}>{errors.phone}</span>}
              </div>
              
              <div style={styles.inputGroup}>
                <label style={styles.label}>Password *</label>
                <input 
                  name="password" 
                  type="password" 
                  placeholder="Create a strong password" 
                  onChange={handleChange}
                  value={form.password}
                  style={{
                    ...styles.input,
                    ...(errors.password ? styles.inputError : {})
                  }}
                  required
                  disabled={isLoading}
                />
                {errors.password && <span style={styles.errorText}>{errors.password}</span>}
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Confirm Password *</label>
                <input 
                  name="confirmPassword" 
                  type="password" 
                  placeholder="Confirm your password" 
                  onChange={handleChange}
                  value={form.confirmPassword}
                  style={{
                    ...styles.input,
                    ...(errors.confirmPassword ? styles.inputError : {})
                  }}
                  required
                  disabled={isLoading}
                />
                {errors.confirmPassword && <span style={styles.errorText}>{errors.confirmPassword}</span>}
              </div>
              
              <button 
                type="submit" 
                style={{
                  ...styles.registerButton,
                  ...(isLoading ? styles.registerButtonDisabled : {})
                }}
                disabled={isLoading}
              >
                {isLoading ? (
                  <div style={styles.loadingContainer}>
                    <div style={styles.loadingSpinner}></div>
                    Creating Account...
                  </div>
                ) : (
                  "Create Account"
                )}
              </button>
            </form>

            {msg && (
              <div style={
                msg.includes("successful") || msg.includes("success") ? styles.successMessage : styles.errorMessage
              }>
                {msg}
              </div>
            )}

            <div style={styles.divider}>
              <span style={styles.dividerLine}></span>
              <span style={styles.dividerText}>Already have an account?</span>
              <span style={styles.dividerLine}></span>
            </div>

            <button 
              type="button" 
              onClick={goToLogin} 
              style={styles.loginButton}
              disabled={isLoading}
            >
              Sign In to Your Account
            </button>

            <div style={styles.termsNote}>
              <p style={styles.termsText}>
                By creating an account, you agree to our <a href="#" style={styles.termsLink}>Terms of Service</a> and <a href="#" style={styles.termsLink}>Privacy Policy</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  pageContainer: {
    minHeight: '100vh',
    display: 'flex',
    backgroundColor: '#ffffff',
    fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
  },
  backgroundSection: {
    flex: 1,
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '2rem',
    color: 'white',
    position: 'relative',
    overflow: 'hidden',
  },
  heroContent: {
    maxWidth: '500px',
    textAlign: 'center',
    zIndex: 2,
  },
  logoSection: {
    marginBottom: '3rem',
  },
  logoCircle: {
    width: '80px',
    height: '80px',
    borderRadius: '50%',
    background: 'rgba(255, 255, 255, 0.2)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    margin: '0 auto 1.5rem',
    backdropFilter: 'blur(10px)',
  },
  logoIcon: {
    fontSize: '2.5rem',
  },
  heroTitle: {
    fontSize: '2.5rem',
    fontWeight: '700',
    margin: '0 0 1rem 0',
    background: 'linear-gradient(135deg, #fff, #e2e8f0)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
  },
  heroSubtitle: {
    fontSize: '1.125rem',
    opacity: 0.9,
    lineHeight: 1.6,
    margin: 0,
  },
  benefitsList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
  },
  benefitItem: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '0.75rem',
    fontSize: '1rem',
    opacity: 0.9,
  },
  benefitIcon: {
    fontSize: '1.25rem',
  },
  registerSection: {
    flex: '0 0 480px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '2rem',
    background: '#f8fafc',
  },
  registerContainer: {
    width: '100%',
    maxWidth: '400px',
  },
  registerCard: {
    backgroundColor: 'white',
    padding: '2.5rem',
    borderRadius: '16px',
    boxShadow: '0 10px 25px rgba(0, 0, 0, 0.05)',
    border: '1px solid #e2e8f0',
  },
  registerHeader: {
    textAlign: 'center',
    marginBottom: '2rem',
  },
  title: {
    margin: '0 0 0.5rem 0',
    fontSize: '1.75rem',
    fontWeight: '700',
    color: '#1e293b',
  },
  subtitle: {
    margin: 0,
    color: '#64748b',
    fontSize: '0.875rem',
  },
  form: {
    width: '100%',
  },
  inputGroup: {
    marginBottom: '1.25rem',
  },
  label: {
    display: 'block',
    marginBottom: '0.5rem',
    fontSize: '0.875rem',
    fontWeight: '500',
    color: '#374151',
  },
  input: {
    width: '100%',
    padding: '0.875rem 1rem',
    border: '1px solid #d1d5db',
    borderRadius: '8px',
    fontSize: '0.875rem',
    boxSizing: 'border-box',
    transition: 'all 0.2s ease',
    outline: 'none',
    backgroundColor: '#fff',
  },
  inputError: {
    borderColor: '#dc2626',
    boxShadow: '0 0 0 3px rgba(220, 38, 38, 0.1)',
  },
  inputFocus: {
    borderColor: '#3b82f6',
    boxShadow: '0 0 0 3px rgba(59, 130, 246, 0.1)',
  },
  errorText: {
    display: 'block',
    marginTop: '0.25rem',
    fontSize: '0.75rem',
    color: '#dc2626',
  },
  registerButton: {
    width: '100%',
    padding: '0.875rem 1rem',
    backgroundColor: '#10b981',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '0.875rem',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    marginBottom: '1.5rem',
  },
  registerButtonDisabled: {
    backgroundColor: '#9ca3af',
    cursor: 'not-allowed',
  },
  loadingContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '0.5rem',
  },
  loadingSpinner: {
    width: '16px',
    height: '16px',
    border: '2px solid transparent',
    borderTop: '2px solid currentColor',
    borderRadius: '50%',
    animation: 'spin 1s linear infinite',
  },
  errorMessage: {
    padding: '0.875rem 1rem',
    borderRadius: '8px',
    textAlign: 'center',
    marginBottom: '1.5rem',
    fontSize: '0.875rem',
    backgroundColor: '#fef2f2',
    color: '#dc2626',
    border: '1px solid #fecaca',
  },
  successMessage: {
    padding: '0.875rem 1rem',
    borderRadius: '8px',
    textAlign: 'center',
    marginBottom: '1.5rem',
    fontSize: '0.875rem',
    backgroundColor: '#f0fdf4',
    color: '#16a34a',
    border: '1px solid #bbf7d0',
  },
  divider: {
    display: 'flex',
    alignItems: 'center',
    margin: '1.5rem 0',
    gap: '1rem',
  },
  dividerLine: {
    flex: 1,
    height: '1px',
    backgroundColor: '#e2e8f0',
  },
  dividerText: {
    color: '#64748b',
    fontSize: '0.75rem',
    fontWeight: '500',
    whiteSpace: 'nowrap',
  },
  loginButton: {
    width: '100%',
    padding: '0.875rem 1rem',
    backgroundColor: 'transparent',
    color: '#374151',
    border: '1px solid #d1d5db',
    borderRadius: '8px',
    fontSize: '0.875rem',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    marginBottom: '1.5rem',
  },
  termsNote: {
    textAlign: 'center',
  },
  termsText: {
    margin: 0,
    fontSize: '0.75rem',
    color: '#64748b',
    lineHeight: 1.5,
  },
  termsLink: {
    color: '#3b82f6',
    textDecoration: 'none',
  },
};

// Add CSS animations
const styleSheet = document.styleSheets[0];
styleSheet.insertRule(`
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`, styleSheet.cssRules.length);

// Add hover effects
styles.input[':hover'] = {
  borderColor: '#9ca3af',
};

styles.input[':focus'] = styles.inputFocus;

styles.registerButton[':hover'] = !styles.registerButtonDisabled && {
  backgroundColor: '#059669',
  transform: 'translateY(-1px)',
};

styles.loginButton[':hover'] = {
  backgroundColor: '#3b82f6',
  color: 'white',
  borderColor: '#3b82f6',
};

styles.termsLink[':hover'] = {
  textDecoration: 'underline',
};

export default Register;