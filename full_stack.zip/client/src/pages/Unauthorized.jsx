// client/src/pages/Unauthorized.jsx
import React from 'react';
export default function Unauthorized() {
  return (
    <div style={{ padding: 20 }}>
      <h3>Unauthorized</h3>
      <p>You do not have permission to view this page.</p>
    </div>
  );
}
