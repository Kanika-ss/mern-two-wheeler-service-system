// import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;


import React from "react";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Register from "./pages/Register";
import Login from "./pages/Login";
import AdminDashboard from "./pages/admin/Dashboard";
import MechanicDashboard from "./pages/mechanic/Dashboard";
import UserDashboard from "./pages/user/Dashboard";

function Home() {

return (
    <div
      style={{
        minHeight: "100vh",
        // backgroundImage: "url('/images/bg.jpg')",
        backgroundColor: "#E3F2FD",
        backgroundSize: "cover",
        backgroundPosition: "center",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <header
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "10px 50px",
          backgroundColor: "rgba(201, 213, 213, 0.8)",
        }}
      >
        <div style={{ display: "flex", alignItems: "center" }}>
          <img
            src="/images/logo.png"
            alt="Logo"
            style={{ width: 50, height: 50, marginRight: 10 }}
          />
          <h2>Two Wheeler Service Center</h2>
        </div>
        <nav>
          <Link to="/login" style={{ margin: "0 10px" }}>Login</Link>
          <Link to="/register" style={{ margin: "0 10px" }}>Register</Link>
          {/* <Link to="#contact" style={{ margin: "0 10px" }}>Contact Us</Link> */}
        </nav>
      </header>

      
      <main
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          textAlign: "center",
          padding: "0 20px",
        }}
      >
        <h1>Welcome to Two Wheeler Service</h1>
        <p style={{ maxWidth: 600, marginTop: 10 }}>
          We provide top-notch servicing and maintenance for all two-wheeler bikes.
          Experienced mechanics, quality parts, and fast service – everything to keep
          your bike running smoothly.
        </p>
      </main>

      <footer
        id="contact"
        style={{
          padding: "20px 50px",
          backgroundColor: "rgba(0,0,0,0.7)",
          color: "#fff",
          textAlign: "center",
        }}
      >
        Contact us: servicecenter@example.com | +91 9876543210
      </footer>
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/admin/dashboard" element={<AdminDashboard />} />
        <Route path="/mechanic/dashboard" element={<MechanicDashboard />} />
        <Route path="/user/dashboard" element={<UserDashboard />} />
        <Route path="/admin/dashboard" element={<AdminDashboard />} />
        <Route path="/mechanic/dashboard" element={<MechanicDashboard />} />
        <Route path="/" element={<Home />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
