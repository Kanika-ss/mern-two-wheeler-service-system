import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import { useNavigate } from 'react-router-dom';

const AdminDashboard = () => {
  const [bookings, setBookings] = useState([]);
  const [users, setUsers] = useState([]);
  const [mechanics, setMechanics] = useState([]);
  const [assignData, setAssignData] = useState({ bookingId: '', mechanicId: '' });
  const [newMechanic, setNewMechanic] = useState({ name: '', email: '', password: '', phone: '' });
  const [editMechanic, setEditMechanic] = useState(null);
  const [msg, setMsg] = useState('');
  const [activeTab, setActiveTab] = useState('overview');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  const [assigningBooking, setAssigningBooking] = useState(null);
  const navigate = useNavigate();

  const fetchBookings = async () => {
    try {
      const res = await api.get('/api/admin/bookings');
      setBookings(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchUsers = async () => {
    try {
      const res = await api.get('/api/admin/users');
      setUsers(res.data.filter((u) => u.role === 'mechanic'));
    } catch (err) {
      console.error(err);
    }
  };

  const fetchMechanics = async () => {
    try {
      const res = await api.get('/api/admin/mechanics');
      setMechanics(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchBookings();
    fetchUsers();
    fetchMechanics();
  }, []);

  const handleAssign = async (e) => {
    e.preventDefault();
    if (!assignData.bookingId || !assignData.mechanicId) {
      setMsg('Please select both booking and mechanic.');
      return;
    }

    try {
      const res = await api.post('/api/admin/assign-mechanic', assignData);
      setMsg(res.data.msg);
      fetchBookings();
      setAssignData({ bookingId: '', mechanicId: '' });
      setAssigningBooking(null);
    } catch (err) {
      setMsg(err.response?.data?.msg || 'Error assigning mechanic');
    }
  };

  const handleQuickAssign = async (bookingId, mechanicId) => {
    if (!mechanicId) {
      setMsg('Please select a mechanic.');
      return;
    }

    try {
      const res = await api.post('/api/admin/assign-mechanic', {
        bookingId,
        mechanicId
      });
      setMsg(res.data.msg);
      fetchBookings();
      setAssigningBooking(null);
    } catch (err) {
      setMsg(err.response?.data?.msg || 'Error assigning mechanic');
    }
  };

  const handleCreateMechanic = async (e) => {
    e.preventDefault();
    try {
      if (editMechanic) {
        const res = await api.put(`/api/admin/mechanics/${editMechanic._id}`, newMechanic);
        setMsg(res.data.msg);
        setEditMechanic(null);
      } else {
        const res = await api.post('/api/admin/mechanics', newMechanic);
        setMsg(res.data.msg);
      }
      setNewMechanic({ name: '', email: '', password: '', phone: '' });
      fetchMechanics();
    } catch (err) {
      setMsg(err.response?.data?.msg || 'Error saving mechanic');
    }
  };

  const handleEditMechanic = (mech) => {
    setEditMechanic(mech);
    setNewMechanic({ name: mech.name, email: mech.email, phone: mech.phone, password: '' });
    setActiveTab('mechanics');
  };

  const handleDeleteMechanic = async (id) => {
    if (!window.confirm('Are you sure you want to delete this mechanic?')) return;
    try {
      const res = await api.delete(`/api/admin/mechanics/${id}`);
      setMsg(res.data.msg);
      fetchMechanics();
    } catch (err) {
      setMsg(err.response?.data?.msg || 'Error deleting mechanic');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  // Pagination calculations
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentBookings = bookings.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(bookings.length / itemsPerPage);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  // Statistics for dashboard
  const totalBookings = bookings.length;
  const pendingBookings = bookings.filter(b => b.status === 'Pending').length;
  const completedBookings = bookings.filter(b => b.status === 'Completed').length;
  const totalMechanics = mechanics.length;

  return (
    <div style={styles.pageContainer}>
      {/* Header */}
      <header style={styles.header}>
        <div style={styles.headerLeft}>
          <div style={styles.logoSection}>
            <img src="/images/logo.png" alt="Logo" style={styles.logo} />
            <h2 style={styles.logoText}>Two Wheeler Service</h2>
          </div>
          <nav style={styles.nav}>
            <button 
              style={{...styles.navButton, ...(activeTab === 'overview' ? styles.navButtonActive : {})}}
              onClick={() => setActiveTab('overview')}
            >
              Overview
            </button>
            <button 
              style={{...styles.navButton, ...(activeTab === 'mechanics' ? styles.navButtonActive : {})}}
              onClick={() => setActiveTab('mechanics')}
            >
              Mechanics
            </button>
            <button 
              style={{...styles.navButton, ...(activeTab === 'bookings' ? styles.navButtonActive : {})}}
              onClick={() => setActiveTab('bookings')}
            >
              Bookings & Assign
            </button>
          </nav>
        </div>
        <div style={styles.headerRight}>
          <span style={styles.adminBadge}>Admin</span>
          <button style={styles.logoutButton} onClick={handleLogout}>
            Logout
          </button>
        </div>
      </header>

      {/* Main Content */}
      <div style={styles.content}>
        {/* Welcome Section */}
        <div style={styles.welcomeSection}>
          <h1 style={styles.welcomeTitle}>Admin Dashboard</h1>
          <p style={styles.welcomeSubtitle}>
            Manage mechanics, assign them to bookings, and monitor service status.
          </p>
        </div>

        {/* Message Display */}
        {msg && (
          <div style={msg.includes('Error') ? styles.errorAlert : styles.successAlert}>
            {msg}
            <button style={styles.alertClose} onClick={() => setMsg('')}>×</button>
          </div>
        )}

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div>
            {/* Statistics Cards */}
            <div style={styles.statsGrid}>
              <div style={styles.statCard}>
                <div style={styles.statIcon}>
                  <span style={styles.statNumber}>{totalBookings}</span>
                </div>
                <div style={styles.statInfo}>
                  <h3 style={styles.statTitle}>Total Bookings</h3>
                  <p style={styles.statDescription}>All service requests</p>
                </div>
              </div>
              
              <div style={styles.statCard}>
                <div style={{...styles.statIcon, background: '#ff9800'}}>
                  <span style={styles.statNumber}>{pendingBookings}</span>
                </div>
                <div style={styles.statInfo}>
                  <h3 style={styles.statTitle}>Pending</h3>
                  <p style={styles.statDescription}>Awaiting service</p>
                </div>
              </div>
              
              <div style={styles.statCard}>
                <div style={{...styles.statIcon, background: '#4caf50'}}>
                  <span style={styles.statNumber}>{completedBookings}</span>
                </div>
                <div style={styles.statInfo}>
                  <h3 style={styles.statTitle}>Completed</h3>
                  <p style={styles.statDescription}>Services done</p>
                </div>
              </div>
              
              <div style={styles.statCard}>
                <div style={{...styles.statIcon, background: '#2196f3'}}>
                  <span style={styles.statNumber}>{totalMechanics}</span>
                </div>
                <div style={styles.statInfo}>
                  <h3 style={styles.statTitle}>Mechanics</h3>
                  <p style={styles.statDescription}>Active staff</p>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div style={styles.quickActions}>
              <h3 style={styles.sectionTitle}>Quick Actions</h3>
              <div style={styles.actionButtons}>
                <button 
                  style={styles.actionButton}
                  onClick={() => setActiveTab('mechanics')}
                >
                  Add New Mechanic
                </button>
                <button 
                  style={styles.actionButton}
                  onClick={() => setActiveTab('bookings')}
                >
                  Manage Bookings
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Mechanics Tab */}
        {activeTab === 'mechanics' && (
          <div style={styles.tabContent}>
            <div style={styles.card}>
              <h3 style={styles.cardTitle}>
                {editMechanic ? 'Edit Mechanic' : 'Add New Mechanic'}
              </h3>
              <form onSubmit={handleCreateMechanic} style={styles.form}>
                <div style={styles.formGrid}>
                  <input
                    placeholder="Full Name"
                    value={newMechanic.name}
                    onChange={(e) => setNewMechanic({ ...newMechanic, name: e.target.value })}
                    style={styles.input}
                    required
                  />
                  <input
                    placeholder="Email Address"
                    type="email"
                    value={newMechanic.email}
                    onChange={(e) => setNewMechanic({ ...newMechanic, email: e.target.value })}
                    style={styles.input}
                    required
                  />
                  <input
                    placeholder="Phone Number"
                    value={newMechanic.phone}
                    onChange={(e) => setNewMechanic({ ...newMechanic, phone: e.target.value })}
                    style={styles.input}
                    required
                  />
                  <input
                    placeholder="Password"
                    type="password"
                    value={newMechanic.password}
                    onChange={(e) => setNewMechanic({ ...newMechanic, password: e.target.value })}
                    style={styles.input}
                    required={!editMechanic}
                  />
                </div>
                <div style={styles.buttonGroup}>
                  <button type="submit" style={styles.primaryButton}>
                    {editMechanic ? 'Update Mechanic' : 'Add Mechanic'}
                  </button>
                  {editMechanic && (
                    <button 
                      type="button" 
                      style={styles.secondaryButton}
                      onClick={() => {
                        setEditMechanic(null);
                        setNewMechanic({ name: '', email: '', password: '', phone: '' });
                      }}
                    >
                      Cancel Edit
                    </button>
                  )}
                </div>
              </form>
            </div>

            <div style={styles.card}>
              <h3 style={styles.cardTitle}>Mechanic Details</h3>
              <div style={styles.tableContainer}>
                <table style={styles.table}>
                  <thead>
                    <tr>
                      <th style={styles.th}>Name</th>
                      <th style={styles.th}>Email</th>
                      <th style={styles.th}>Phone</th>
                      <th style={styles.th}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mechanics.map((m) => (
                      <tr key={m._id} style={styles.tr}>
                        <td style={styles.td}>{m.name}</td>
                        <td style={styles.td}>{m.email}</td>
                        <td style={styles.td}>{m.phone}</td>
                        <td style={styles.td}>
                          <div style={styles.actionButtons}>
                            <button 
                              onClick={() => handleEditMechanic(m)} 
                              style={styles.editButton}
                            >
                              Edit
                            </button>
                            <button 
                              onClick={() => handleDeleteMechanic(m._id)} 
                              style={styles.deleteButton}
                            >
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {mechanics.length === 0 && (
                  <div style={styles.emptyState}>
                    No mechanics found. Add your first mechanic above.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Combined Bookings & Assign Tab */}
        {activeTab === 'bookings' && (
          <div style={styles.tabContent}>
            {/* <div style={styles.card}>
              <h3 style={styles.cardTitle}>Assign Mechanic to Booking</h3>
              <form onSubmit={handleAssign} style={styles.form}>
                <div style={styles.formGrid}>
                  <div style={styles.selectGroup}>
                    <label style={styles.label}>Select Booking</label>
                    <select
                      value={assignData.bookingId}
                      onChange={(e) => setAssignData({ ...assignData, bookingId: e.target.value })}
                      style={styles.select}
                    >
                      <option value="">Choose a booking...</option>
                      {bookings.filter(b => !b.assignedMechanic).map((b) => (
                        <option key={b._id} value={b._id}>
                          {b.bikeBrand} {b.bikeModel} - {b.user?.name} ({b.serviceType})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div style={styles.selectGroup}>
                    <label style={styles.label}>Select Mechanic</label>
                    <select
                      value={assignData.mechanicId}
                      onChange={(e) => setAssignData({ ...assignData, mechanicId: e.target.value })}
                      style={styles.select}
                    >
                      <option value="">Choose a mechanic...</option>
                      {mechanics.map((m) => (
                        <option key={m._id} value={m._id}>{m.name}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <button 
                  type="submit" 
                  style={styles.primaryButton}
                  disabled={!assignData.bookingId || !assignData.mechanicId}
                >
                  Assign Mechanic
                </button>
              </form>
            </div> */}

            {/* Bookings Table with Pagination */}
            <div style={styles.card}>
              <div style={styles.cardHeader}>
                <h3 style={styles.cardTitle}>All Bookings</h3>
                <div style={styles.headerInfo}>
                  <span style={styles.badge}>{bookings.length} total bookings</span>
                  <span style={styles.pageInfo}>
                    Showing {indexOfFirstItem + 1}-{Math.min(indexOfLastItem, bookings.length)} of {bookings.length}
                  </span>
                </div>
              </div>
              
              <div style={styles.tableContainer}>
                <table style={styles.table}>
                  <thead>
                    <tr>
                      <th style={styles.th}>Bike Details</th>
                      <th style={styles.th}>Customer</th>
                      <th style={styles.th}>Service Type</th>
                      <th style={styles.th}>Date & Time</th>
                      <th style={styles.th}>Status</th>
                      <th style={styles.th}>Assigned Mechanic</th>
                      <th style={styles.th}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {currentBookings.map((b) => (
                      <tr key={b._id} style={styles.tr}>
                        <td style={styles.td}>
                          <div style={styles.bikeInfo}>
                            <strong>{b.bikeBrand} {b.bikeModel}</strong>
                            <small style={styles.bikeReg}>{b.registrationNumber || 'N/A'}</small>
                          </div>
                        </td>
                        <td style={styles.td}>
                          <div>
                            <div style={styles.customerName}>{b.user?.name}</div>
                            <div style={styles.customerContact}>{b.user?.phone || b.user?.email}</div>
                          </div>
                        </td>
                        <td style={styles.td}>
                          <span style={styles.serviceBadge}>{b.serviceType}</span>
                        </td>
                        <td style={styles.td}>
                          <div style={styles.dateTime}>
                            <div>{new Date(b.pickupDate).toLocaleDateString()}</div>
                            <div style={styles.time}>{b.pickupTime}</div>
                          </div>
                        </td>
                        <td style={styles.td}>
                          <span style={{
                            ...styles.statusBadge,
                            ...(b.status === 'completed' ? styles.statusCompleted : 
                                 b.status === 'in progress' ? styles.statusProgress : 
                                 styles.statusPending)
                          }}>
                            {b.status}
                          </span>
                        </td>
                        <td style={styles.td}>
                          {b.assignedMechanic ? (
                            <div style={styles.assignedMechanic}>
                              <div style={styles.mechanicName}>{b.assignedMechanic.name}</div>
                              <button 
                                style={styles.changeAssignButton}
                                onClick={() => setAssigningBooking(b._id)}
                              >
                                Change
                              </button>
                            </div>
                          ) : (
                            <div style={styles.unassignedSection}>
                              <span style={styles.unassigned}>Not assigned</span>
                              <button 
                                style={styles.assignButton}
                                onClick={() => setAssigningBooking(b._id)}
                              >
                                Assign
                              </button>
                            </div>
                          )}
                        </td>
                        <td style={styles.td}>
                          {assigningBooking === b._id && (
                            <div style={styles.quickAssign}>
                              <select
                                style={styles.quickSelect}
                                onChange={(e) => handleQuickAssign(b._id, e.target.value)}
                                defaultValue=""
                              >
                                <option value="">Select mechanic</option>
                                {mechanics.map((m) => (
                                  <option key={m._id} value={m._id}>{m.name}</option>
                                ))}
                              </select>
                              <button 
                                style={styles.cancelAssignButton}
                                onClick={() => setAssigningBooking(null)}
                              >
                                ×
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {bookings.length === 0 && (
                  <div style={styles.emptyState}>
                    No bookings found.
                  </div>
                )}
              </div>

              {/* Pagination Controls */}
              {totalPages > 1 && (
                <div style={styles.pagination}>
                  <button
                    style={{...styles.paginationButton, ...(currentPage === 1 ? styles.paginationDisabled : {})}}
                    onClick={() => paginate(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    Previous
                  </button>
                  
                  <div style={styles.paginationNumbers}>
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map(number => (
                      <button
                        key={number}
                        style={{...styles.paginationNumber, ...(currentPage === number ? styles.paginationActive : {})}}
                        onClick={() => paginate(number)}
                      >
                        {number}
                      </button>
                    ))}
                  </div>
                  
                  <button
                    style={{...styles.paginationButton, ...(currentPage === totalPages ? styles.paginationDisabled : {})}}
                    onClick={() => paginate(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    Next
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const styles = {
  pageContainer: {
    fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    background: '#f8fafc',
    minHeight: '100vh',
    color: '#334155',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '0 2rem',
    background: '#fff',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    borderBottom: '1px solid #e2e8f0',
    height: '70px',
  },
  headerLeft: {
    display: 'flex',
    alignItems: 'center',
    gap: '3rem',
  },
  logoSection: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
  },
  logo: {
    width: '40px',
    height: '40px',
  },
  logoText: {
    margin: 0,
    fontSize: '1.25rem',
    fontWeight: '700',
    color: '#1e293b',
  },
  nav: {
    display: 'flex',
    gap: '0.5rem',
  },
  navButton: {
    padding: '0.5rem 1rem',
    background: 'transparent',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.875rem',
    fontWeight: '500',
    color: '#64748b',
    transition: 'all 0.2s',
  },
  navButtonActive: {
    background: '#3b82f6',
    color: '#fff',
  },
  headerRight: {
    display: 'flex',
    alignItems: 'center',
    gap: '1rem',
  },
  adminBadge: {
    background: '#f1f5f9',
    color: '#475569',
    padding: '0.25rem 0.75rem',
    borderRadius: '20px',
    fontSize: '0.75rem',
    fontWeight: '600',
  },
  logoutButton: {
    padding: '0.5rem 1rem',
    background: '#ef4444',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.875rem',
    fontWeight: '500',
    transition: 'background 0.2s',
  },
  content: {
    padding: '2rem',
    maxWidth: '1400px',
    margin: '0 auto',
  },
  welcomeSection: {
    marginBottom: '2rem',
  },
  welcomeTitle: {
    fontSize: '2rem',
    fontWeight: '700',
    color: '#1e293b',
    margin: '0 0 0.5rem 0',
  },
  welcomeSubtitle: {
    fontSize: '1.125rem',
    color: '#64748b',
    margin: 0,
  },
  statsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '1.5rem',
    marginBottom: '2rem',
  },
  statCard: {
    background: '#fff',
    padding: '1.5rem',
    borderRadius: '12px',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    display: 'flex',
    alignItems: 'center',
    gap: '1rem',
    border: '1px solid #e2e8f0',
  },
  statIcon: {
    width: '60px',
    height: '60px',
    borderRadius: '12px',
    background: '#3b82f6',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#fff',
    fontSize: '1.5rem',
    fontWeight: '700',
  },
  statNumber: {
    fontSize: '1.5rem',
    fontWeight: '700',
  },
  statInfo: {
    flex: 1,
  },
  statTitle: {
    margin: '0 0 0.25rem 0',
    fontSize: '1rem',
    fontWeight: '600',
    color: '#1e293b',
  },
  statDescription: {
    margin: 0,
    fontSize: '0.875rem',
    color: '#64748b',
  },
  quickActions: {
    background: '#fff',
    padding: '1.5rem',
    borderRadius: '12px',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    border: '1px solid #e2e8f0',
  },
  sectionTitle: {
    margin: '0 0 1rem 0',
    fontSize: '1.25rem',
    fontWeight: '600',
    color: '#1e293b',
  },
  actionButtons: {
    display: 'flex',
    gap: '1rem',
    flexWrap: 'wrap',
  },
  actionButton: {
    padding: '0.75rem 1.5rem',
    background: '#3b82f6',
    color: '#fff',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '0.875rem',
    fontWeight: '500',
    transition: 'background 0.2s',
  },
  tabContent: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1.5rem',
  },
  card: {
    background: '#fff',
    padding: '1.5rem',
    borderRadius: '12px',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    border: '1px solid #e2e8f0',
  },
  cardHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '1.5rem',
    flexWrap: 'wrap',
    gap: '1rem',
  },
  headerInfo: {
    display: 'flex',
    alignItems: 'center',
    gap: '1rem',
  },
  cardTitle: {
    margin: 0,
    fontSize: '1.25rem',
    fontWeight: '600',
    color: '#1e293b',
  },
  badge: {
    background: '#f1f5f9',
    color: '#475569',
    padding: '0.25rem 0.75rem',
    borderRadius: '20px',
    fontSize: '0.75rem',
    fontWeight: '600',
  },
  pageInfo: {
    fontSize: '0.875rem',
    color: '#64748b',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
  },
  formGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '1rem',
  },
  input: {
    padding: '0.75rem 1rem',
    border: '1px solid #d1d5db',
    borderRadius: '8px',
    fontSize: '0.875rem',
    transition: 'border-color 0.2s, box-shadow 0.2s',
  },
  selectGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.5rem',
  },
  label: {
    fontSize: '0.875rem',
    fontWeight: '500',
    color: '#374151',
  },
  select: {
    padding: '0.75rem 1rem',
    border: '1px solid #d1d5db',
    borderRadius: '8px',
    fontSize: '0.875rem',
    background: '#fff',
    cursor: 'pointer',
  },
  primaryButton: {
    padding: '0.75rem 1.5rem',
    background: '#3b82f6',
    color: '#fff',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '0.875rem',
    fontWeight: '500',
    transition: 'background 0.2s',
    alignSelf: 'flex-start',
  },
  secondaryButton: {
    padding: '0.75rem 1.5rem',
    background: 'transparent',
    color: '#64748b',
    border: '1px solid #d1d5db',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '0.875rem',
    fontWeight: '500',
    transition: 'all 0.2s',
    marginLeft: '0.5rem',
  },
  buttonGroup: {
    display: 'flex',
    gap: '0.5rem',
    alignItems: 'center',
  },
  tableContainer: {
    overflowX: 'auto',
    borderRadius: '8px',
    border: '1px solid #e2e8f0',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    fontSize: '0.875rem',
  },
  th: {
    background: '#f8fafc',
    padding: '1rem',
    textAlign: 'left',
    fontWeight: '600',
    color: '#374151',
    borderBottom: '1px solid #e2e8f0',
    whiteSpace: 'nowrap',
  },
  tr: {
    borderBottom: '1px solid #e2e8f0',
    transition: 'background 0.2s',
  },
  td: {
    padding: '1rem',
    borderBottom: '1px solid #e2e8f0',
    verticalAlign: 'top',
  },
  editButton: {
    padding: '0.375rem 0.75rem',
    background: '#3b82f6',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.75rem',
    fontWeight: '500',
    marginRight: '0.5rem',
  },
  deleteButton: {
    padding: '0.375rem 0.75rem',
    background: '#ef4444',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.75rem',
    fontWeight: '500',
  },
  bikeInfo: {
    display: 'flex',
    flexDirection: 'column',
  },
  bikeReg: {
    fontSize: '0.75rem',
    color: '#64748b',
    marginTop: '0.25rem',
  },
  customerName: {
    fontWeight: '500',
  },
  customerContact: {
    fontSize: '0.75rem',
    color: '#64748b',
    marginTop: '0.25rem',
  },
  serviceBadge: {
    background: '#f1f5f9',
    color: '#475569',
    padding: '0.25rem 0.5rem',
    borderRadius: '4px',
    fontSize: '0.75rem',
    fontWeight: '500',
  },
  dateTime: {
    display: 'flex',
    flexDirection: 'column',
  },
  time: {
    fontSize: '0.75rem',
    color: '#64748b',
  },
  statusBadge: {
    padding: '0.25rem 0.75rem',
    borderRadius: '20px',
    fontSize: '0.75rem',
    fontWeight: '500',
    textTransform: 'capitalize',
  },
  statusPending: {
    background: '#fef3c7',
    color: '#d97706',
  },
  statusProgress: {
    background: '#dbeafe',
    color: '#1d4ed8',
  },
  statusCompleted: {
    background: '#dcfce7',
    color: '#166534',
  },
  assignedMechanic: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.25rem',
  },
  mechanicName: {
    fontWeight: '500',
  },
  changeAssignButton: {
    padding: '0.25rem 0.5rem',
    background: 'transparent',
    color: '#3b82f6',
    border: '1px solid #3b82f6',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '0.7rem',
  },
  unassignedSection: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.25rem',
  },
  unassigned: {
    color: '#ef4444',
    fontStyle: 'italic',
    fontSize: '0.875rem',
  },
  assignButton: {
    padding: '0.25rem 0.5rem',
    background: '#10b981',
    color: '#fff',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '0.7rem',
  },
  quickAssign: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem',
  },
  quickSelect: {
    padding: '0.25rem 0.5rem',
    border: '1px solid #d1d5db',
    borderRadius: '4px',
    fontSize: '0.75rem',
    background: '#fff',
    cursor: 'pointer',
  },
  cancelAssignButton: {
    padding: '0.25rem 0.5rem',
    background: '#ef4444',
    color: '#fff',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '0.75rem',
  },
  emptyState: {
    padding: '3rem 2rem',
    textAlign: 'center',
    color: '#64748b',
    fontSize: '0.875rem',
  },
  pagination: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '1rem',
    borderTop: '1px solid #e2e8f0',
  },
  paginationButton: {
    padding: '0.5rem 1rem',
    background: '#3b82f6',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.875rem',
    fontWeight: '500',
  },
  paginationDisabled: {
    background: '#9ca3af',
    cursor: 'not-allowed',
  },
  paginationNumbers: {
    display: 'flex',
    gap: '0.5rem',
  },
  paginationNumber: {
    padding: '0.5rem 0.75rem',
    background: 'transparent',
    color: '#374151',
    border: '1px solid #d1d5db',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.875rem',
  },
  paginationActive: {
    background: '#3b82f6',
    color: '#fff',
    borderColor: '#3b82f6',
  },
  successAlert: {
    background: '#dcfce7',
    color: '#166534',
    padding: '1rem',
    borderRadius: '8px',
    marginBottom: '1.5rem',
    border: '1px solid #bbf7d0',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  errorAlert: {
    background: '#fef2f2',
    color: '#dc2626',
    padding: '1rem',
    borderRadius: '8px',
    marginBottom: '1.5rem',
    border: '1px solid #fecaca',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  alertClose: {
    background: 'transparent',
    border: 'none',
    color: 'inherit',
    fontSize: '1.25rem',
    cursor: 'pointer',
    padding: 0,
    width: '24px',
    height: '24px',
  },
};

export default AdminDashboard;
