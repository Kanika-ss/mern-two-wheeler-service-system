import React, { useState, useEffect, useContext, useCallback } from 'react';
import { AuthContext } from '../../context/AuthContext';
import api from '../../services/api';
import { useNavigate } from 'react-router-dom';

const MechanicDashboard = () => {
  const { user, authLoading } = useContext(AuthContext);
  const [bookings, setBookings] = useState([]);
  const [updateData, setUpdateData] = useState({
    bookingId: '',
    status: '',
    remarks: '',
    cost: '',
  });
  const [activeTab, setActiveTab] = useState('bookings');
  const [message, setMessage] = useState('');
  const [selectedBooking, setSelectedBooking] = useState(null);

  const navigate = useNavigate();

  const fetchBookings = useCallback(async () => {
    if (!user) return;
    try {
      const res = await api.get('/api/mechanic/bookings');
      setBookings(res.data);
    } catch (err) {
      console.error('Failed to fetch bookings', err);
      setMessage('Failed to load bookings');
    }
  }, [user]);

  useEffect(() => {
    fetchBookings();
  }, [fetchBookings]);

  const handleUpdate = async (e) => {
    e.preventDefault();
    if (!updateData.bookingId || !updateData.status) {
      setMessage('Please select booking and status');
      return;
    }
    try {
      const res = await api.post('/api/mechanic/update', updateData);
      setMessage(res.data.msg);
      fetchBookings();
      setUpdateData({ bookingId: '', status: '', remarks: '', cost: '' });
      setSelectedBooking(null);
    } catch (err) {
      setMessage(err.response?.data?.msg || 'Error updating booking');
    }
  };

  const handleSelectBooking = (booking) => {
    setSelectedBooking(booking);
    setUpdateData({
      bookingId: booking._id,
      status: booking.status,
      remarks: booking.remarks || '',
      cost: booking.cost || ''
    });
    setActiveTab('update');
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  // Statistics
  const assignedBookings = bookings.length;
  const pendingBookings = bookings.filter(b => b.status === 'pending').length;
  const inProgressBookings = bookings.filter(b => b.status === 'in progress').length;
  const completedBookings = bookings.filter(b => b.status === 'completed').length;

  if (authLoading) return (
    <div style={styles.loadingContainer}>
      <div style={styles.loadingSpinner}></div>
      <p>Loading dashboard...</p>
    </div>
  );
  
  if (!user) return (
    <div style={styles.errorContainer}>
      <h3>Authentication Required</h3>
      <p>Please login to view dashboard</p>
      <button style={styles.primaryButton} onClick={() => navigate('/login')}>
        Go to Login
      </button>
    </div>
  );

  return (
    <div style={styles.pageContainer}>
      {/* Header */}
      <header style={styles.header}>
        <div style={styles.headerLeft}>
          <div style={styles.logoSection}>
            <img src="/images/logo.png" alt="Logo" style={styles.logo} />
            <h2 style={styles.logoText}>Two Wheeler Service</h2>
          </div>
          <nav style={styles.nav}>
            <button 
              style={{...styles.navButton, ...(activeTab === 'bookings' ? styles.navButtonActive : {})}}
              onClick={() => setActiveTab('bookings')}
            >
              My Bookings
            </button>
            <button 
              style={{...styles.navButton, ...(activeTab === 'update' ? styles.navButtonActive : {})}}
              onClick={() => setActiveTab('update')}
            >
              Update Status
            </button>
          </nav>
        </div>
        <div style={styles.headerRight}>
          <div style={styles.userInfo}>
            <span style={styles.userName}>{user?.name}</span>
            <span style={styles.userRole}>Mechanic</span>
          </div>
          <button style={styles.logoutButton} onClick={handleLogout}>
            Logout
          </button>
        </div>
      </header>

      {/* Main Content */}
      <div style={styles.content}>
        {/* Welcome Section */}
        <div style={styles.welcomeSection}>
          <h1 style={styles.welcomeTitle}>Welcome back, {user?.name}! 👋</h1>
          <p style={styles.welcomeSubtitle}>
            Manage your assigned bookings and update service progress.
          </p>
        </div>

        {/* Message Display */}
        {message && (
          <div style={message.includes('Error') ? styles.errorAlert : styles.successAlert}>
            {message}
            <button style={styles.alertClose} onClick={() => setMessage('')}>×</button>
          </div>
        )}

        {/* Statistics Cards */}
        <div style={styles.statsGrid}>
          <div style={styles.statCard}>
            <div style={{...styles.statIcon, background: '#3b82f6'}}>
              <span style={styles.statNumber}>{assignedBookings}</span>
            </div>
            <div style={styles.statInfo}>
              <h3 style={styles.statTitle}>Assigned</h3>
              <p style={styles.statDescription}>Total bookings</p>
            </div>
          </div>
          
          <div style={styles.statCard}>
            <div style={{...styles.statIcon, background: '#f59e0b'}}>
              <span style={styles.statNumber}>{pendingBookings}</span>
            </div>
            <div style={styles.statInfo}>
              <h3 style={styles.statTitle}>Pending</h3>
              <p style={styles.statDescription}>Awaiting service</p>
            </div>
          </div>
          
          <div style={styles.statCard}>
            <div style={{...styles.statIcon, background: '#8b5cf6'}}>
              <span style={styles.statNumber}>{inProgressBookings}</span>
            </div>
            <div style={styles.statInfo}>
              <h3 style={styles.statTitle}>In Progress</h3>
              <p style={styles.statDescription}>Currently working</p>
            </div>
          </div>
          
          <div style={styles.statCard}>
            <div style={{...styles.statIcon, background: '#10b981'}}>
              <span style={styles.statNumber}>{completedBookings}</span>
            </div>
            <div style={styles.statInfo}>
              <h3 style={styles.statTitle}>Completed</h3>
              <p style={styles.statDescription}>Jobs done</p>
            </div>
          </div>
        </div>

        {/* Bookings Tab */}
        {activeTab === 'bookings' && (
          <div style={styles.tabContent}>
            <div style={styles.card}>
              <div style={styles.cardHeader}>
                <h3 style={styles.cardTitle}>Assigned Bookings</h3>
                <span style={styles.badge}>{bookings.length} bookings</span>
              </div>
              
              {bookings.length === 0 ? (
                <div style={styles.emptyState}>
                  <div style={styles.emptyIcon}>🔧</div>
                  <h4>No Bookings Assigned</h4>
                  <p>You don't have any assigned bookings at the moment.</p>
                </div>
              ) : (
                <div style={styles.tableContainer}>
                  <table style={styles.table}>
                    <thead>
                      <tr>
                        <th style={styles.th}>Customer Details</th>
                        <th style={styles.th}>Bike Information</th>
                        <th style={styles.th}>Service Type</th>
                        <th style={styles.th}>Date & Time</th>
                        <th style={styles.th}>Status</th>
                        <th style={styles.th}>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {bookings.map((booking) => (
                        <tr key={booking._id} style={styles.tr}>
                          <td style={styles.td}>
                            <div style={styles.customerInfo}>
                              <strong>{booking.user?.name}</strong>
                              <div style={styles.customerContact}>
                                {booking.user?.phone || booking.user?.email}
                              </div>
                            </div>
                          </td>
                          <td style={styles.td}>
                            <div style={styles.bikeInfo}>
                              <strong>{booking.bikeBrand} {booking.bikeModel}</strong>
                              {booking.registrationNumber && (
                                <div style={styles.regNumber}>{booking.registrationNumber}</div>
                              )}
                            </div>
                          </td>
                          <td style={styles.td}>
                            <span style={styles.serviceBadge}>{booking.serviceType}</span>
                          </td>
                          <td style={styles.td}>
                            <div style={styles.dateTime}>
                              <div>{new Date(booking.deliveryDate).toLocaleDateString()}</div>
                              <div style={styles.time}>{booking.deliveryTime}</div>
                            </div>
                          </td>
                          <td style={styles.td}>
                            <span style={{
                              ...styles.statusBadge,
                              ...(booking.status === 'completed' ? styles.statusCompleted : 
                                   booking.status === 'in progress' ? styles.statusProgress : 
                                   styles.statusPending)
                            }}>
                              {booking.status}
                            </span>
                          </td>
                          <td style={styles.td}>
                            <button 
                              onClick={() => handleSelectBooking(booking)}
                              style={styles.updateButton}
                            >
                              Update
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Update Tab */}
        {activeTab === 'update' && (
          <div style={styles.tabContent}>
            <div style={styles.card}>
              <h3 style={styles.cardTitle}>
                {selectedBooking ? 'Update Booking Status' : 'Select Booking to Update'}
              </h3>
              
              {!selectedBooking && (
                <div style={styles.bookingSelector}>
                  <h4 style={styles.selectorTitle}>Choose a booking to update:</h4>
                  <div style={styles.bookingGrid}>
                    {bookings.map((booking) => (
                      <div 
                        key={booking._id} 
                        style={styles.bookingCard}
                        onClick={() => handleSelectBooking(booking)}
                      >
                        <div style={styles.bookingHeader}>
                          <strong>{booking.bikeBrand} {booking.bikeModel}</strong>
                          <span style={{
                            ...styles.statusSmall,
                            ...(booking.status === 'completed' ? styles.statusCompleted : 
                                 booking.status === 'in progress' ? styles.statusProgress : 
                                 styles.statusPending)
                          }}>
                            {booking.status}
                          </span>
                        </div>
                        <div style={styles.bookingDetails}>
                          <div>Customer: {booking.user?.name}</div>
                          <div>Service: {booking.serviceType}</div>
                          <div>Date: {new Date(booking.deliveryDate).toLocaleDateString()}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {selectedBooking && (
                <form onSubmit={handleUpdate} style={styles.form}>
                  <div style={styles.selectedBooking}>
                    <h4>Selected Booking:</h4>
                    <div style={styles.bookingSummary}>
                      <strong>{selectedBooking.bikeBrand} {selectedBooking.bikeModel}</strong>
                      <span> - {selectedBooking.user?.name} ({selectedBooking.serviceType})</span>
                    </div>
                    <button 
                      type="button" 
                      style={styles.secondaryButton}
                      onClick={() => {
                        setSelectedBooking(null);
                        setUpdateData({ bookingId: '', status: '', remarks: '', cost: '' });
                      }}
                    >
                      Change Booking
                    </button>
                  </div>

                  <div style={styles.formGrid}>
                    <div style={styles.formGroup}>
                      <label style={styles.label}>Service Status *</label>
                      <select
                        value={updateData.status}
                        onChange={(e) => setUpdateData({ ...updateData, status: e.target.value })}
                        style={styles.select}
                        required
                      >
                        <option value="">Select Status</option>
                        <option value="pending">Pending</option>
                        <option value="in Progress">In Progress</option>
                        <option value="completed">Completed</option>
                      </select>
                    </div>

                    <div style={styles.formGroup}>
                      <label style={styles.label}>Service Cost (₹)</label>
                      <input
                        placeholder="Enter service cost"
                        type="number"
                        value={updateData.cost}
                        onChange={(e) => setUpdateData({ ...updateData, cost: e.target.value })}
                        style={styles.input}
                      />
                    </div>
                  </div>

                  <div style={styles.formGroup}>
                    <label style={styles.label}>Service Remarks</label>
                    <textarea
                      placeholder="Add any remarks about the service..."
                      value={updateData.remarks}
                      onChange={(e) => setUpdateData({ ...updateData, remarks: e.target.value })}
                      style={styles.textarea}
                      rows="4"
                    />
                  </div>

                  <div style={styles.buttonGroup}>
                    <button type="submit" style={styles.primaryButton}>
                      Update Booking Status
                    </button>
                    <button 
                      type="button" 
                      style={styles.secondaryButton}
                      onClick={() => {
                        setSelectedBooking(null);
                        setUpdateData({ bookingId: '', status: '', remarks: '', cost: '' });
                      }}
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const styles = {
  pageContainer: {
    fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    background: '#f8fafc',
    minHeight: '100vh',
    color: '#334155',
  },
  loadingContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100vh',
    gap: '1rem',
  },
  loadingSpinner: {
    width: '40px',
    height: '40px',
    border: '4px solid #e2e8f0',
    borderTop: '4px solid #3b82f6',
    borderRadius: '50%',
    animation: 'spin 1s linear infinite',
  },
  errorContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100vh',
    gap: '1rem',
    textAlign: 'center',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '0 2rem',
    background: '#fff',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    borderBottom: '1px solid #e2e8f0',
    height: '70px',
  },
  headerLeft: {
    display: 'flex',
    alignItems: 'center',
    gap: '3rem',
  },
  logoSection: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
  },
  logo: {
    width: '40px',
    height: '40px',
  },
  logoText: {
    margin: 0,
    fontSize: '1.25rem',
    fontWeight: '700',
    color: '#1e293b',
  },
  nav: {
    display: 'flex',
    gap: '0.5rem',
  },
  navButton: {
    padding: '0.5rem 1rem',
    background: 'transparent',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.875rem',
    fontWeight: '500',
    color: '#64748b',
    transition: 'all 0.2s',
  },
  navButtonActive: {
    background: '#3b82f6',
    color: '#fff',
  },
  headerRight: {
    display: 'flex',
    alignItems: 'center',
    gap: '1rem',
  },
  userInfo: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-end',
  },
  userName: {
    fontWeight: '600',
    fontSize: '0.875rem',
  },
  userRole: {
    fontSize: '0.75rem',
    color: '#64748b',
  },
  logoutButton: {
    padding: '0.5rem 1rem',
    background: '#ef4444',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.875rem',
    fontWeight: '500',
    transition: 'background 0.2s',
  },
  content: {
    padding: '2rem',
    maxWidth: '1200px',
    margin: '0 auto',
  },
  welcomeSection: {
    marginBottom: '2rem',
  },
  welcomeTitle: {
    fontSize: '2rem',
    fontWeight: '700',
    color: '#1e293b',
    margin: '0 0 0.5rem 0',
  },
  welcomeSubtitle: {
    fontSize: '1.125rem',
    color: '#64748b',
    margin: 0,
  },
  statsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
    gap: '1rem',
    marginBottom: '2rem',
  },
  statCard: {
    background: '#fff',
    padding: '1.5rem',
    borderRadius: '12px',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    display: 'flex',
    alignItems: 'center',
    gap: '1rem',
    border: '1px solid #e2e8f0',
  },
  statIcon: {
    width: '50px',
    height: '50px',
    borderRadius: '10px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#fff',
    fontSize: '1.25rem',
    fontWeight: '700',
  },
  statNumber: {
    fontSize: '1.25rem',
  },
  statInfo: {
    flex: 1,
  },
  statTitle: {
    margin: '0 0 0.25rem 0',
    fontSize: '0.875rem',
    fontWeight: '600',
    color: '#1e293b',
  },
  statDescription: {
    margin: 0,
    fontSize: '0.75rem',
    color: '#64748b',
  },
  tabContent: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1.5rem',
  },
  card: {
    background: '#fff',
    padding: '1.5rem',
    borderRadius: '12px',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    border: '1px solid #e2e8f0',
  },
  cardHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '1.5rem',
  },
  cardTitle: {
    margin: 0,
    fontSize: '1.25rem',
    fontWeight: '600',
    color: '#1e293b',
  },
  badge: {
    background: '#f1f5f9',
    color: '#475569',
    padding: '0.25rem 0.75rem',
    borderRadius: '20px',
    fontSize: '0.75rem',
    fontWeight: '600',
  },
  emptyState: {
    padding: '3rem 2rem',
    textAlign: 'center',
    color: '#64748b',
  },
  emptyIcon: {
    fontSize: '3rem',
    marginBottom: '1rem',
  },
  tableContainer: {
    overflowX: 'auto',
    borderRadius: '8px',
    border: '1px solid #e2e8f0',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    fontSize: '0.875rem',
  },
  th: {
    background: '#f8fafc',
    padding: '1rem',
    textAlign: 'left',
    fontWeight: '600',
    color: '#374151',
    borderBottom: '1px solid #e2e8f0',
    whiteSpace: 'nowrap',
  },
  tr: {
    borderBottom: '1px solid #e2e8f0',
    transition: 'background 0.2s',
  },
  td: {
    padding: '1rem',
    borderBottom: '1px solid #e2e8f0',
    verticalAlign: 'top',
  },
  customerInfo: {
    display: 'flex',
    flexDirection: 'column',
  },
  customerContact: {
    fontSize: '0.75rem',
    color: '#64748b',
    marginTop: '0.25rem',
  },
  bikeInfo: {
    display: 'flex',
    flexDirection: 'column',
  },
  regNumber: {
    fontSize: '0.75rem',
    color: '#64748b',
    marginTop: '0.25rem',
  },
  serviceBadge: {
    background: '#f1f5f9',
    color: '#475569',
    padding: '0.25rem 0.5rem',
    borderRadius: '4px',
    fontSize: '0.75rem',
    fontWeight: '500',
  },
  dateTime: {
    display: 'flex',
    flexDirection: 'column',
  },
  time: {
    fontSize: '0.75rem',
    color: '#64748b',
  },
  statusBadge: {
    padding: '0.375rem 0.75rem',
    borderRadius: '20px',
    fontSize: '0.75rem',
    fontWeight: '500',
    textTransform: 'capitalize',
  },
  statusSmall: {
    padding: '0.25rem 0.5rem',
    borderRadius: '12px',
    fontSize: '0.7rem',
    fontWeight: '500',
    textTransform: 'capitalize',
  },
  statusPending: {
    background: '#fef3c7',
    color: '#d97706',
  },
  statusProgress: {
    background: '#dbeafe',
    color: '#1d4ed8',
  },
  statusCompleted: {
    background: '#dcfce7',
    color: '#166534',
  },
  updateButton: {
    padding: '0.5rem 1rem',
    background: '#3b82f6',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '0.75rem',
    fontWeight: '500',
    transition: 'background 0.2s',
  },
  bookingSelector: {
    marginBottom: '1.5rem',
  },
  selectorTitle: {
    margin: '0 0 1rem 0',
    fontSize: '1rem',
    color: '#374151',
  },
  bookingGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
    gap: '1rem',
  },
  bookingCard: {
    padding: '1rem',
    border: '1px solid #e2e8f0',
    borderRadius: '8px',
    cursor: 'pointer',
    transition: 'all 0.2s',
  },
  bookingHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '0.5rem',
  },
  bookingDetails: {
    fontSize: '0.875rem',
    color: '#64748b',
    display: 'flex',
    flexDirection: 'column',
    gap: '0.25rem',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1.5rem',
  },
  selectedBooking: {
    background: '#f8fafc',
    padding: '1rem',
    borderRadius: '8px',
    border: '1px solid #e2e8f0',
  },
  bookingSummary: {
    margin: '0.5rem 0',
    fontSize: '1rem',
  },
  formGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
    gap: '1rem',
  },
  formGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.5rem',
  },
  label: {
    fontSize: '0.875rem',
    fontWeight: '500',
    color: '#374151',
  },
  select: {
    padding: '0.75rem',
    border: '1px solid #d1d5db',
    borderRadius: '8px',
    fontSize: '0.875rem',
    background: '#fff',
    cursor: 'pointer',
  },
  input: {
    padding: '0.75rem',
    border: '1px solid #d1d5db',
    borderRadius: '8px',
    fontSize: '0.875rem',
  },
  textarea: {
    padding: '0.75rem',
    border: '1px solid #d1d5db',
    borderRadius: '8px',
    fontSize: '0.875rem',
    resize: 'vertical',
    fontFamily: 'inherit',
  },
  buttonGroup: {
    display: 'flex',
    gap: '1rem',
    alignItems: 'center',
  },
  primaryButton: {
    padding: '0.75rem 1.5rem',
    background: '#3b82f6',
    color: '#fff',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '0.875rem',
    fontWeight: '500',
    transition: 'background 0.2s',
  },
  secondaryButton: {
    padding: '0.75rem 1.5rem',
    background: 'transparent',
    color: '#64748b',
    border: '1px solid #d1d5db',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '0.875rem',
    fontWeight: '500',
    transition: 'all 0.2s',
  },
  successAlert: {
    background: '#dcfce7',
    color: '#166534',
    padding: '1rem',
    borderRadius: '8px',
    marginBottom: '1.5rem',
    border: '1px solid #bbf7d0',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  errorAlert: {
    background: '#fef2f2',
    color: '#dc2626',
    padding: '1rem',
    borderRadius: '8px',
    marginBottom: '1.5rem',
    border: '1px solid #fecaca',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  alertClose: {
    background: 'transparent',
    border: 'none',
    color: 'inherit',
    fontSize: '1.25rem',
    cursor: 'pointer',
    padding: 0,
    width: '24px',
    height: '24px',
  },
};

// Add CSS animation for loading spinner
const styleSheet = document.styleSheets[0];
styleSheet.insertRule(`
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`, styleSheet.cssRules.length);

export default MechanicDashboard;