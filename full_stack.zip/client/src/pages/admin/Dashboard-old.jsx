import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import { useNavigate } from 'react-router-dom';

const AdminDashboard = () => {
  const [bookings, setBookings] = useState([]);
  const [users, setUsers] = useState([]);
  const [mechanics, setMechanics] = useState([]);
  const [assignData, setAssignData] = useState({ bookingId: '', mechanicId: '' });
  const [newMechanic, setNewMechanic] = useState({ name: '', email: '', password: '', phone: '' });
  const [editMechanic, setEditMechanic] = useState(null);
  const [msg, setMsg] = useState('');
  const navigate = useNavigate();

  const fetchBookings = async () => {
    try {
      const res = await api.get('/api/admin/bookings');
      setBookings(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchUsers = async () => {
    try {
      const res = await api.get('/api/admin/users');
      setUsers(res.data.filter((u) => u.role === 'mechanic'));
    } catch (err) {
      console.error(err);
    }
  };

  const fetchMechanics = async () => {
    try {
      const res = await api.get('/api/admin/mechanics');
      setMechanics(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchBookings();
    fetchUsers();
    fetchMechanics();
  }, []);

  const handleAssign = async (e) => {
    e.preventDefault();
    if (!assignData.bookingId || !assignData.mechanicId) {
      setMsg('Please select both booking and mechanic.');
      return;
    }

    try {
      const res = await api.post('/api/admin/assign-mechanic', assignData);
      setMsg(res.data.msg);
      fetchBookings();
      setAssignData({ bookingId: '', mechanicId: '' });
    } catch (err) {
      setMsg(err.response?.data?.msg || 'Error assigning mechanic');
    }
  };


  const handleCreateMechanic = async (e) => {
    e.preventDefault();
    try {
      if (editMechanic) {
        const res = await api.put(`/api/admin/mechanics/${editMechanic._id}`, newMechanic);
        setMsg(res.data.msg);
        setEditMechanic(null);
      } else {
        const res = await api.post('/api/admin/mechanics', newMechanic);
        setMsg(res.data.msg);
      }
      setNewMechanic({ name: '', email: '', password: '', phone: '' });
      fetchMechanics();
    } catch (err) {
      setMsg(err.response?.data?.msg || 'Error saving mechanic');
    }
  };

  const handleEditMechanic = (mech) => {
    setEditMechanic(mech);
    setNewMechanic({ name: mech.name, email: mech.email, phone: mech.phone, password: '' });
  };

  const handleDeleteMechanic = async (id) => {
    if (!window.confirm('Are you sure you want to delete this mechanic?')) return;
    try {
      const res = await api.delete(`/api/admin/mechanics/${id}`);
      setMsg(res.data.msg);
      fetchMechanics();
    } catch (err) {
      setMsg(err.response?.data?.msg || 'Error deleting mechanic');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <div style={styles.pageContainer}>
      <header style={styles.header}>
        <div style={styles.logoSection}>
          <img src="/images/logo.png" alt="Logo" style={styles.logo} />
          <h2 style={{ margin: 0 }}>Two Wheeler Service</h2>
        </div>
        <nav style={styles.nav}>
          <span style={styles.navItem}>Settings</span>
          <span style={styles.navItem} onClick={handleLogout}>Logout</span>
        </nav>
      </header>

      <div style={styles.content}>
        <h2>Welcome, Admin</h2>
        <p style={styles.description}>
          Manage mechanics, assign them to bookings, and monitor service status.
        </p>

        <div style={styles.formCard}>
          <h3>{editMechanic ? 'Edit Mechanic' : 'Add Mechanic'}</h3>
          <form onSubmit={handleCreateMechanic} style={styles.form}>
            <input
              placeholder="Name"
              value={newMechanic.name}
              onChange={(e) => setNewMechanic({ ...newMechanic, name: e.target.value })}
              style={styles.input}
              required
            />
            <input
              placeholder="Email"
              type="email"
              value={newMechanic.email}
              onChange={(e) => setNewMechanic({ ...newMechanic, email: e.target.value })}
              style={styles.input}
              required
            />
            <input
              placeholder="Phone"
              value={newMechanic.phone}
              onChange={(e) => setNewMechanic({ ...newMechanic, phone: e.target.value })}
              style={styles.input}
              required
            />
            <input
              placeholder="Password"
              type="password"
              value={newMechanic.password}
              onChange={(e) => setNewMechanic({ ...newMechanic, password: e.target.value })}
              style={styles.input}
              required={!editMechanic}
            />
            <button type="submit" style={styles.submitButton}>
              {editMechanic ? 'Update Mechanic' : 'Add Mechanic'}
            </button>
          </form>

          <br></br><h3>Mechanic Details</h3>
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>Name</th>
                <th style={styles.th}>Email</th>
                <th style={styles.th}>Phone</th>
                <th style={styles.th}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {mechanics.map((m) => (
                <tr key={m._id}>
                  <td style={styles.td}>{m.name}</td>
                  <td style={styles.td}>{m.email}</td>
                  <td style={styles.td}>{m.phone}</td>
                  <td style={styles.td}>
                    <button onClick={() => handleEditMechanic(m)} style={styles.editBtn}>Edit</button>
                    <button onClick={() => handleDeleteMechanic(m._id)} style={styles.deleteBtn}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div style={styles.formCard}>
          <h3>Assign Mechanic to Booking</h3>
          <form onSubmit={handleAssign} style={styles.form}>
            <select
              value={assignData.bookingId}
              onChange={(e) => setAssignData({ ...assignData, bookingId: e.target.value })}
              style={styles.input}
            >
              <option value="">Select Booking</option>
              {bookings.map((b) => (
                <option key={b._id} value={b._id}>
                  {b.bikeBrand} {b.bikeModel} - {b.user?.name}
                </option>
              ))}
            </select>

            <select
              value={assignData.mechanicId}
              onChange={(e) => setAssignData({ ...assignData, mechanicId: e.target.value })}
              style={styles.input}
            >
              <option value="">Select Mechanic</option>
              {mechanics.map((m) => (
                <option key={m._id} value={m._id}>{m.name}</option>
              ))}
            </select>

            <button type="submit" style={styles.submitButton}>Assign</button>
          </form>
        </div>

        <div style={styles.tableCard}>
          <h3>All Bookings</h3>
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>Bike</th>
                <th style={styles.th}>User</th>
                <th style={styles.th}>Service Type</th>
                <th style={styles.th}>Date</th>
                <th style={styles.th}>Time</th>
                <th style={styles.th}>Status</th>
                <th style={styles.th}>Assigned Mechanic</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((b) => (
                <tr key={b._id}>
                  <td style={styles.td}>{b.bikeBrand} {b.bikeModel}</td>
                  <td style={styles.td}>{b.user?.name}</td>
                  <td style={styles.td}>{b.serviceType}</td>
                  <td style={styles.td}>{new Date(b.pickupDate).toLocaleDateString()}</td>
                  <td style={styles.td}>{b.pickupTime}</td>
                  <td style={styles.td}>{b.status}</td>
                  <td style={styles.td}>{b.assignedMechanic?.name || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {msg && <p style={msg.includes('Error') ? styles.errorMsg : styles.successMsg}>{msg}</p>}
      </div>
    </div>
  );
};

const styles = {
  pageContainer: {
    fontFamily: 'Arial, sans-serif',
    background: '#f5f5f5',
    minHeight: '100vh',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    background: '#333',
    color: '#fff',
  },
  logoSection: {
    display: 'flex',
    alignItems: 'center',
  },
  logo: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
  nav: {
    display: 'flex',
    gap: 20,
  },
  navItem: {
    cursor: 'pointer',
    textDecoration: 'underline',
  },
  content: {
    padding: '30px 60px',
  },
  description: {
    fontSize: 16,
    marginBottom: 20,
  },
  formCard: {
    background: '#fff',
    padding: 20,
    borderRadius: 8,
    marginBottom: 30,
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
  },
  input: {
    display: 'block',
    width: '98%',
    padding: 10,
    marginBottom: 10,
    borderRadius: 4,
    border: '1px solid #ccc',
  },
  submitButton: {
    padding: '10px 20px',
    background: '#333',
    color: '#fff',
    border: 'none',
    borderRadius: 4,
    cursor: 'pointer',
  },
  editBtn: {
    padding: '6px 10px',
    marginRight: 6,
    background: '#4caf50',
    color: '#fff',
    border: 'none',
    borderRadius: 4,
    cursor: 'pointer',
  },
  deleteBtn: {
    padding: '6px 10px',
    background: '#f44336',
    color: '#fff',
    border: 'none',
    borderRadius: 4,
    cursor: 'pointer',
  },
  successMsg: { color: 'green', marginTop: 10 },
  errorMsg: { color: 'red', marginTop: 10 },
  tableCard: {
    background: '#fff',
    padding: 20,
    borderRadius: 8,
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
    overflowX: 'auto',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    textAlign: 'center',
  },
  th: {
    background: '#333',
    color: '#fff',
    padding: '12px 8px',
    borderBottom: '2px solid #444',
  },
  td: {
    padding: '10px 8px',
    borderBottom: '1px solid #ddd',
  },
};

export default AdminDashboard;













// import React, { useState, useEffect } from 'react';
// import api from '../../services/api';

// const AdminDashboard = () => {
//   const [bookings, setBookings] = useState([]);
//   const [users, setUsers] = useState([]);
//   const [assignData, setAssignData] = useState({ bookingId: '', mechanicId: '' });

//   const fetchBookings = async () => {
//     const res = await api.get('/api/admin/bookings');
//     setBookings(res.data);
//   };

//   const fetchUsers = async () => {
//     const res = await api.get('/api/admin/users');
//     setUsers(res.data.filter(u => u.role === 'mechanic'));
//   };

//   useEffect(() => {
//     fetchBookings();
//     fetchUsers();
//   }, []);

//   const handleAssign = async () => {
//     try {
//       const res = await api.post('/api/admin/assign-mechanic', assignData);
//       alert(res.data.msg);
//       fetchBookings();
//     } catch (err) {
//       alert(err.response?.data?.msg || 'Error assigning mechanic');
//     }
//   };

//   return (
//     <div style={{ padding: 20 }}>
//       <h2>Admin Dashboard</h2>

//       <h3>All Bookings</h3>
//       <table border="1" cellPadding="5">
//         <thead>
//           <tr>
//             <th>Bike</th>
//             <th>User</th>
//             <th>Service</th>
//             <th>Date</th>
//             <th>Time</th>
//             <th>Status</th>
//             <th>Assigned Mechanic</th>
//           </tr>
//         </thead>
//         <tbody>
//           {bookings.map(b => (
//             <tr key={b._id}>
//               <td>{b.bikeBrand} {b.bikeModel}</td>
//               <td>{b.user?.name}</td>
//               <td>{b.serviceType}</td>
//               <td>{new Date(b.preferredDate).toLocaleDateString()}</td>
//               <td>{b.preferredTime}</td>
//               <td>{b.status}</td>
//               <td>{b.assignedMechanic?.name || '-'}</td>
//             </tr>
//           ))}
//         </tbody>
//       </table>

//       <h3>Assign Mechanic</h3>
//       <select onChange={e => setAssignData({ ...assignData, bookingId: e.target.value })}>
//         <option value="">Select Booking</option>
//         {bookings.map(b => <option key={b._id} value={b._id}>{b.bikeBrand} {b.bikeModel}</option>)}
//       </select>
//       <select onChange={e => setAssignData({ ...assignData, mechanicId: e.target.value })}>
//         <option value="">Select Mechanic</option>
//         {users.map(u => <option key={u._id} value={u._id}>{u.name}</option>)}
//       </select>
//       <button onClick={handleAssign}>Assign</button>
//     </div>
//   );
// };

// export default AdminDashboard;
